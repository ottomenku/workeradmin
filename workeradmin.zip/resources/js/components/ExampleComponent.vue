

<script>

 new Vue({
  el: '#example',
 
  data: {
      message: "sgbfdndfnnfhhn",
    posts: [
      { id: 1, title: 'My journey with Vue' },
      { id: 2, title: 'Blogging with Vue' },
      { id: 3, title: 'Why Vue is so fun' }
    ]
  }
})
</script>