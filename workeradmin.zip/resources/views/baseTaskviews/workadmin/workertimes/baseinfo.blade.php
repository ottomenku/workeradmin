<center><h3>Dolgozói idők jóváhagyása info</h3></center>
<div style="padding:15px;">
Ha a dolgozó bejegyzést tesz a naptárába az nem látsódik rögtön ,  csak ha itt jóváhagyjuk a 
<a href=" " class="btn btn-success btn-xs" title="unPub">
    <i class="fa fa-check-square-o" aria-hidden="true"></i></a>
gombra kattintva. Ekkor az állpot mezőben  
is ugyan ilyenre vált.
</br></br>
A <span class="btn btn-danger btn-xs" title="Add New Wroletime">
    <i class="fa fa-times" aria-hidden="true"></i></span>  gombra kattintunk letilthatjuk. az adott változtatást. ekkor nem látszódik  a naptárban
és a dolgozó nem tudja sem törölni sem újra felvinni.
</br></br>
A <button type="submit" class="btn btn-danger btn-xs" ><i class="fa fa-trash-o" aria-hidden="true"></i></button> gombra kattintva törölhető a sor.
</br></br>
 Az új gombra kattintva lehetőség van közvetlenül felvinni nap mbejegyzést
</div>