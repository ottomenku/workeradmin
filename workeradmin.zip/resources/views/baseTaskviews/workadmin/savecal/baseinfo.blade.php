<center><h3>Naptár mentések info</h3></center>
<div style="padding:15px;">
A program mindig az adott beállításoknalk megfelelően generálja le a dolgozók naptárait.
Kivéve ha az adott hónapra van mentés. Akkor azt jeleníti meg. Ha több is van akkor az utolsót.
Ha egy dolgozó hónapja végleges lesz érdemes menteni, hogy ha például a következő hónapban 
másik  műszakba tesszük át visszamenőleg ne változzon. 

    </br></br>
    A naptár mentés menüpontban kiválaszthatjuk hogy melyik dolgozónak  akrunk mentést készíteni.

</br></br>
Az        <button class="btn btn-info btn-xs">
    <i class="fa fa-calendar" aria-hidden="true"></i> </button> gombra kattintva lehet a műszak naptárát szerkeszteni.
</br>
gombra kattintantva meg lehet nézni az adott mentést.
</br></br>
A <button class="btn btn-info btn-xs">
    <i class="fa fa-list" aria-hidden="true"></i> solver</button> gombra kattintva a program egy összesítést készít az adott mentésről.

            </div>