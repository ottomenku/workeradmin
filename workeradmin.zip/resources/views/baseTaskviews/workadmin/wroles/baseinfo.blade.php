<center><h3> Munkarendek menü info</h3></center>
<div style="padding:15px;">
     Az itt felvitt munkarendeket lehet a műszakok és a dolgozók naptárában beállítani. Új munkarend felvitele esetén először csak a nevét és esetleges megjegyzést lehet megadni . Ha el lett mentve akkor lehet időket hozzádani. Vagyishogy mettől meddig milyen időtipussal kell dolgozni annak aki ebben a munkarendben van.
</div>