<center><h3>Dolgozói naptárak szerkesztése, mentése info</h3></center>
<div style="padding:15px;">

Az        <button class="btn btn-info btn-xs">
    <i class="fa fa-calendar" aria-hidden="true"></i> </button> gombra kattintva lehet
     az adott dolgozó  naptárát szerkeszteni, menteni.
</br>
<h4> A naptár használata:</h4>
A mégsem gombra kattintva visszatér az előző oldalra.
</br>A Küldés gomb elmenti a változtatásokat azokra a napokra amiknek a jelölő négyzete ki van pipálva.
</br> a törlés gomb törli a  napok bejegyzéseit.
ha a mellette lévő idők jelöló négyzet ki van pipálva akkor a napokon lévő összes időt törli.
ha a naptipusok van bejelelölve akkor a naptipus változtatásokat, ha a munkarendek akkor akkor a  munkarendeket törli.
Ha mind be van jelölve akkor értelemszerűen mindet törli.Természetesen a törlés is csak a kijelölt napokra hajtódik végre. 


            </div>