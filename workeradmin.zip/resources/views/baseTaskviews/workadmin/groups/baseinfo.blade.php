<center><h3> Müszakok menü info</h3></center>
<div style="padding:15px;">
   Itt Múszakokat lehet létrehozni.
    </br></br>
  Az   <button class="btn btn-info btn-xs">
            <i class="fa fa-users" aria-hidden="true"></i> </button> gombra kattintav lehet a műszakba dolgozókat felvenni. 
            Az itt felvett dolgozók naptárában automatikusan megjelenik a múszak naptárában létrehozott változás.
        </br>Ezek a dolgozó naptárában felülírhatók.</br>
            Egy dolgozó csak egy múszak tagja  lehet. Ha olyan dolgozót adunk a műszakhoz aki másik műszakbna volt eddig onnam automatikusan átkerül.
</br></br>
    Az        <button class="btn btn-info btn-xs">
                    <i class="fa fa-calendar" aria-hidden="true"></i> </button> gombra kattintva lehet a műszak naptárát szerkeszteni.
                </br>
    <h4> A naptár használata:</h4>
    A mégsem gombra kattintva visszatér az előző oldalra.
</br>A Küldés gomb elmenti a változtatásokat azokra a napokra amiknek a jelölő négyzete ki van pipálva.
</br> a törlés gomb törli a  napok bejegyzéseit.
ha a mellette lévő idők jelöló négyzet ki van pipálva akkor a napokon lévő összes időt törli.
ha a naptipusok van bejelelölve akkor a naptipus változtatásokat, ha a munkarendek akkor akkor a  munkarendeket törli.
Ha mind be van jelölve akkor értelemszerűen mindet törli.Természetesen a törlés is csak a kijelölt napokra hajtódik végre. 
                </div>