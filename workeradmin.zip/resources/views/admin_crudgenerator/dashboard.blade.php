@extends('admin_crudgenerator.backend')

@section('content')


            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">Dashboard</div>

                    <div class="card-body">
                        Your applications dashboard.
                    </div>
                </div>
            </div>
     
@endsection
