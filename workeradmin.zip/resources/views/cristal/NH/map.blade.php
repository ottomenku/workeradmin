frame: ------------------------------
<!-- Login , registry-->
<a class="logo" dusk="login-link"  href="{{ url('/login') }}">Belépés </a>
<a class="logo" dusk="registration-link" href="{{ url('/register') }}"> Regisztráció</a>
<a class="logo" dusk="logout-link"  href="{{ url('/logout') }}"

<!-- dusk="category-head" : Dokumentumok -->
<button  style="right:150px;" dusk="category-head" class="menu-button" id="open-button"><h2  style="font-size:x-large " >Dokumentumok</h2></button>

category: előbukkanó menü -------------------------
<div dusk="category-contener" class="container">