<div style="font-size: 1.3em;">
<i data="check" class="iconbeszur fa fa-check" aria-hidden="true"></i>    
<i data="window-close-o" class="iconbeszur fa fa-window-close-o" aria-hidden="true"></i>
<i data="star-o" class="iconbeszur fa fa-star-o" aria-hidden="true"></i>
<i data="smile-o" class="iconbeszur fa fa-smile-o" aria-hidden="true"></i>
<i data="plus" class="iconbeszur fa fa-plus" aria-hidden="true"></i>
<i data="percent" class="iconbeszur fa fa-percent" aria-hidden="true"></i>
<i data="minus-square-o" class="iconbeszur fa fa-minus-square-o" aria-hidden="true"></i>
<i data="industry" class="iconbeszur fa fa-industry" aria-hidden="true"></i>
<i data="heart" class="iconbeszur fa fa-heart" aria-hidden="true"></i>
<i data="minus-square" class="iconbeszur fa fa-minus-square" aria-hidden="true"></i>
<i data="spinner" class="iconbeszur fa fa-spinner" aria-hidden="true"></i>
<i data="wrench" class="iconbeszur fa fa-wrench" aria-hidden="true"></i>
<i data="times" class="iconbeszur fa fa-times" aria-hidden="true"></i>
<i data="plus-square" class="iconbeszur fa fa-plus-square" aria-hidden="true"></i>
<i data="plane" class="iconbeszur fa fa-paper-plane" aria-hidden="true"></i>
<i data="minus-circle" class="iconbeszur fa fa-minus-circle" aria-hidden="true"></i>
<i data="hourglass-end" class="iconbeszur fa fa-hourglass-end" aria-hidden="true"></i>
<i data="flag" class="iconbeszur fa fa-flag" aria-hidden="true"></i>
<i data="circle-o" class="iconbeszur fa fa-circle-o" aria-hidden="true"></i>
<i data="user-circle-o" class="iconbeszur fa fa-user-circle-o" aria-hidden="true"></i>
<i data="user-times" class="iconbeszur fa fa-user-times" aria-hidden="true"></i>
<i data="times-circle" class="iconbeszur fa fa-times-circle" aria-hidden="true"></i>
<i data="sun-o" class="iconbeszur fa fa-sun-o" aria-hidden="true"></i>
<i data="star-half-o" class="iconbeszur fa fa-star-half-o" aria-hidden="true"></i>
<i data="snowflake-o" class="iconbeszur fa fa-snowflake-o" aria-hidden="true"></i>
<i data="meh-o" class="iconbeszur fa fa-meh-o" aria-hidden="true"></i>
<i data="minus-square-o" class="iconbeszur fa fa-minus-square-o" aria-hidden="true"></i>
<i data="minus-circle" class="iconbeszur fa fa-minus-circle" aria-hidden="true"></i>
<i data="cog" class="iconbeszur fa fa-cog" aria-hidden="true"></i>
<i data="check-square-o" class="iconbeszur fa fa-check-square-o" aria-hidden="true"></i>
<i data="circle-o" class="iconbeszur fa fa-circle-o" aria-hidden="true"></i>
<i data="circle" class="iconbeszur fa fa-circle" aria-hidden="true"></i>
<i data="dot-circle-o" class="iconbeszur fa fa-dot-circle-o" aria-hidden="true"></i>
<i data="minus-square" class="iconbeszur fa fa-minus-square" aria-hidden="true"></i>
<i data="hourglass-start" class="iconbeszur fa fa-hourglass-start" aria-hidden="true"></i>
<i data="heart-o" class="iconbeszur fa fa-heart-o" aria-hidden="true"></i>
<i data="cube" class="iconbeszur fa fa-cube" aria-hidden="true"></i>
<i data="coffee" class="iconbeszur fa fa-coffee" aria-hidden="true"></i>
<i data="adjust" class="iconbeszur fa fa-adjust" aria-hidden="true"></i>
<i data="calendar-o" class="iconbeszur fa fa-calendar-o" aria-hidden="true"></i>
<a href="https://fontawesome.com/v4.7.0/icons/">További ikonok</a>
</div>


<script>
    $( ".iconbeszur" ).click(function() {
        $( "#icon" ).val($(this).attr( 'data' ))  ;
    });
</script>
