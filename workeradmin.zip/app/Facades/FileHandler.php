<?php

namespace App\Facades;

class FileHandler extends \Illuminate\Support\Facades\Facade
{
    public static function getFacadeAccessor()
    {
        return 'FileHandler';
    }
}