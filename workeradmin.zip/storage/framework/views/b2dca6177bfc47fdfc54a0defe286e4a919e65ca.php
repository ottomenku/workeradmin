<!DOCTYPE html> 
<html>
    <head> 
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title>Page Title</title>
        <style> *{font-family: DejaVu Sans !important;} </style>
    <?php
        $dc = new \App\Doctemplate();
        
        $include = 'doc_tmpl.'.$dc->getTemplate($viewpar['id'])->filename ?? $data['id'] ?? $viewpar['include'] ?? '';
    ?>    
</head>
<body>
<?php echo $__env->make($include, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\ujworkertime\workeradmin\resources\views/doc_tmpl/frame.blade.php ENDPATH**/ ?>