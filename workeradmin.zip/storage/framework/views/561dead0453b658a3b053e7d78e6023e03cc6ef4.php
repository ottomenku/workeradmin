<?php $__env->startSection('content'); ?>
<?php 
//$year=$data['year'] ?? $this->PAR['getT']['ev'] ?? \Carbon::now()->year; 
$year=$viewpar['routpars']['id'] ?? Carbon\Carbon::now()->year; 
$ho=$viewpar['routpars']['id1'] ?? Carbon\Carbon::now()->month;
//$checkbutton=$viewpar['calendar']['checkbutton'] ?? true;
$months_magyar=['hónapok','Január','Február','Március','Április','Május','Június','Július','Augusztus','Szeptember','Október','November','Decenber'];
$months=$viewpar['calendar']['months'] ?? $months_magyar; unset($months[0]);// kiveszi az alapfeliratot és 1-el kezdődikaz index nem 0-val!!!!!

//if($ev_ho_formurl_addgetT){$ev_ho_formurl= MoHandF::url($ev_ho_formurl,$viewpar['getT']);}
//<label for="timetype_id" class="col-3 control-label">Naptipus</label>     
 ?>
<style>
    .table th, .table td {
        padding: 0.25rem;
      }
 
      [class*="col-"],  /* Elements whose class attribute begins with "col-" */
      [class^="col-"] { /* Elements whose class attribute contains the substring "col-" */
        padding-left: 5px;
        padding-right: 0;
      }

</style>
<div  class="col-md-9">
    <div class="card">
        <div class="card-header"><?php echo e($viewpar['taskheader'] ?? $viewpar['app_name'] ?? $viewpar['route'] ?? 'index'); ?>

        </div>
        <div class="card-body"> 
                <br>
<div id="app"> 

   <!-- modal-------->
    <modal v-if="showModal" @close="showModal = false">
       
        
        <div slot="body">
<a class="btn btn-primary" v-bind:href="host+'pdf/'+storedid" >Letöltés </a>

       <div>munkanapok : {{solver.sumWorkerdays}}  </div>  
       <div class="" v-for="(wday, dkey) in solver.days">  
            {{dkey}}:  {{wday.days}} , összesen: {{wday.sumdays}}
       </div>
       <div class="" v-for="(wtime, tkey) in solver.times">  
        {{tkey}}:  {{wtime.hours}} , összesen: {{wtime.sumhours}}
   </div>

            <section class="th">
                            
                <span>Hétfő</span>
                <span>Kedd</span>
                <span>Szerda</span>
                <span>Csütörtök</span>
                <span>Péntek</span>
                <span>Szombat</span>
                <span>Vasárnap</span>
            </section>
            <div class="week" v-for="(week, weekindex) in storedToShow.calendar">      
                <div  v-bind:class="item.class" v-for="(item, datum) in week" v-bind:data-date="item.day"> 
                    <div  class="dayheader" v-if="item.name !== 'empty'">
                       
                        <span v-if="typeof basedays[datum] !== 'undefined'" class="dayhead" > 
                            {{basedays[datum]}}
                        </span>
                    </div>    
                <div class="daynumber" > {{item.day}} </div>                 
                <div v-if="typeof(workerdays.datekey[workerid])  !== 'undefined'" >
                    <div  v-bind:class="[workerdays.class]" v-for="workerdays in workerdays.datekey[workerid][datum]" >
                        {{workerdays.daytype.name}} 
                             
                    </div> 
                </div> 
                <div  v-if="typeof(times.datekey[workerid]) !== 'undefined'" >      
                    <div  v-bind:class="[time.class]"  v-for="(time) in times.datekey[workerid][datum]" >
                        {{time.start.substring(0,5)}}- {{time.end.substring(0,5)}}         
                       
                    </div>
                </div> 
                </div> 
            </div> 



        </div>

    </modal>

   <!--  panel---------------------------------------------------------------------->                 
   <div class="container">
   <ul class="nav nav-tabs nav-justified">
    <li class="nav-item">
        <a class="nav-link" @click.prevent="setActive('home')" :class="{ active: isActive('home') }" href="#home">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" @click.prevent="setActive('newform')" :class="{ active: isActive('newform') }" href="#newform">Üj bejegyzés</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" @click.prevent="setActive('stored')" :class="{ active: isActive('stored') }" href="#stored">Zárások</a>
      </li>
  </ul>        
  <div class="tab-content py-3" id="myTabContent">
    <div class="tab-pane fade" :class="{ 'active show': isActive('home') }" id="home">Home content </div>

    <!-- uj form---------------------------------------------------------------------->        
    <div class="tab-pane fade" :class="{ 'active show': isActive('newform') }" id="newform">
        <hr> 
        Kijelölt napok:  {{ datums }}  
        <hr>
        <div class="row">                             

            <div style=" padding-left: 5px; padding-right: 0;" class="col-2">    
                    <input class="form-control" v-model="timeFormDatas.start" name="start" type="time" id="start">       
            </div>      
            <div style=" padding-left: 5px; padding-right: 0;" class="col-2">                                    
                    <input class="form-control" v-model="timeFormDatas.end" name="end" type="time" id="end">                       
            </div>
            <div style=" padding-left: 5px; padding-right: 0;" class="col-2"> 
                    <input class="form-control" v-model="timeFormDatas.hour" name="hour" type="number" id="hour">              
            </div>
            <div style=" padding-left: 5px; padding-right: 20;"  class="col-3">           

                <select class="form-control input-sm " name="timetype_id"  v-model="actTimetype">
                    <option v-for="(timetype, index) in timetypes" :value="index">{{timetype}}</option>
                    </select>
            </div>  
            <button class=" btn btn-primary"  v-on:click="storetimes()" style="margin:2px;" >           
                <i class="fa fa-save"></i>
            </button> 
            <button class=" btn btn-danger" v-on:click="timesreset()" style="margin:2px;">     
                <i class="fa fa-trash"></i>
            </button>       
            
        </div> 
     Munkaidők felvitele a kijelölt napokhoz                
<hr>

        <div class="row">
            <label for="daytype_id" class="col-3 control-label">Naptipus</label>  
              <label for="workernote" class="col-8 control-label">Megjegyzés</label>
        </div>
        <div class="row">     
            <div class="col-3">                     
                <select class="form-control input-sm " name="daytype_id"  v-model="actDaytype">
                    <option v-for="(daytype, index) in daytypes" :value="index">{{daytype}}</option>
                    </select>
            </div> 
          
            <div class="col-6">     
                    <input class="form-control" v-model="dayFormDatas.adnote" name="adnote" type="text" id="workernote">                   
            </div>
    
            <button class=" btn btn-primary" v-on:click="storedays()" style="margin:2px;">           
                <i class="fa fa-save"></i>
            </button> 
            <button class=" btn btn-danger" v-on:click="daysreset()" style="margin:2px;">     
                <i class="fa fa-trash"></i>
            </button>   
        </div>   
        Szabadság betegállomány stb  felvitele a kijelölt napokhoz

        <hr>         
    </div>
    <!-- stored ---------------------------------------------------------------------->        
    <div class="tab-pane fade" :class="{ 'active show': isActive('stored') }" id="stored">
        <div class="table-responsive">
            <table class="table table-borderless">
                <thead>
                    <tr>
                       <th>Dolgozó</th><th>Zárás név</th><th>zárva</th><th>készült</th><th>frissítve</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>      
                    <tr v-for="(stored, key) in storeds">
                                             
                        <td>{{stored.worker.workername}}</td><td>{{stored.name}}</td><td> {{stored.lezarva}}</td>
                        <td> {{stored.created_at}} </td><td> {{stored.updated_at}} </td>
                        <td>
                            <i style="color:blue;size:2x;"  v-on:click="showStored(stored.id)"class="fa fa-eye"></i> 
                        </td>                 
                   
                    </tr>
                      
             
                </tbody>
            </table>
            </div>                      

            <button class=" btn btn-primary" v-on:click="storeStoreds()" style="margin:2px;">           
                <i class="fa fa-save"></i> Zárás/zárás frissítés 
            </button>   
    </div>
<!-- funkció gombok -------------------------------------------------->
</br>
                   <div class="row">    
                    <div class="col-xs-4"> 
                    <div class="input-group">  
                        <span  v-on:click="minusyear()" style="cursor: pointer;" class="btn btn-outline-secondary input-sm"><</span>
                        <input id="ev" size="2"  name="ev" type="text" v-on:change="changeEv()" v-bind:value="ev" class="form-control input-sm ">
                        <span v-on:click="addyear()" style="cursor: pointer;" class="btn btn-outline-secondary input-sm">></span>
                    </div>
                    </div> 

                    <div class="col-xs-2"> 
                        <select class="form-control input-sm " name="ho" v-on:change="changeHo()" v-model="ho">
                            <option v-for="mounth in mounths" :value="mounth.value">{{ mounth.text }}</option>
                        </select>
                    </div>
                    <div class="col-xs-2"> 
                    <select class="form-control input-sm " name="timetype_id"  v-model="actchecklist">
                        <option v-for="(val, index) in checklist" :value="index">{{val}}</option>
                    </select>
                    </div>
                    </div>  
<!-- calendar ---------------------------------------------------------------->
                                  
    <div id="calendar">
       <div v-for="(worker, workerid) in workers"  id="usercalendar"> 
           <hr>
         
            <div><i v-on:click="toggleWorker(workerid)" class="fa fa-chevron-up"></i>  <span>{{worker.fullname}}  </span>
             <input  v-model="workerids"  type="checkbox" name="workerid[]" v-bind:value="workerid">
            </div>
       
        <hr>  
           <div v-bind:id="workerid">             
                    <section class="th">
                            
                            <span>Hétfő</span>
                            <span>Kedd</span>
                            <span>Szerda</span>
                            <span>Csütörtök</span>
                            <span>Péntek</span>
                            <span>Szombat</span>
                            <span>Vasárnap</span>
                        </section>
                        <div class="week" v-for="(week, weekindex) in calendar">      
                            <div  v-bind:class="item.class" v-for="(item, datum) in week" v-bind:data-date="item.day"> 
                                <div v-bind:id="datum" v-on:click="setActive('newform')" class="dayheader" v-if="item.name !== 'empty'">
                                    <span class="" > <input class="{ workday: item.munkanap }" v-model="datums" type="checkbox" name="datum[]" v-bind:value="datum"> </span>
                                    <span v-if="typeof basedays[datum] !== 'undefined'" class="dayhead" > 
                                        {{basedays[datum]}}
                                    </span>
                                </div>    
                            <div class="daynumber" > {{item.day}} </div>                 
                            <div v-if="typeof(workerdays.datekey[workerid])  !== 'undefined'" v-if="typeof(workerdays.datekey[workerid][datum])  !== 'undefined'" >
                                <div  v-on:click="setActive('dayform')" v-bind:class="[workerdays.class]" v-for="workerdays in workerdays.datekey[workerid][datum]" >
                                    {{workerdays.daytype.name}} 
                                    <i v-on:click="delday(workerdays.id)" style="color:red;" class="fa fa-times-circle"></i>       
                                </div> 
                            </div> 
                            <div  v-if="typeof(times.datekey[workerid]) !== 'undefined'"  v-if="typeof(times.datekey[workerid][datum]) !== 'undefined'" >      
                                <div v-on:click="setActive('timeform')" v-bind:class="[time.class]"  v-for="(time) in times.datekey[workerid][datum]" >
                                    {{time.start.substring(0,5)}}- {{time.end.substring(0,5)}}         
                                    <i v-on:click="deltime(time.id)" style="color:red;" class="fa fa-times-circle"></i> 
                                </div>
                            </div> 
                            </div> 
                        </div> 
                </div>     
            </div>  
        </div>    
</div>   



</div>
</div>
</div>

<!-- template for the modal component -->
<script type="text/x-template" id="modal-template">
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">

          <div class="modal-header">
            <slot name="header">
                <button class="modal-default-button" @click="$emit('close')">
                   bezárás
                  </button>
            </slot>
          </div>

          <div class="modal-body">
            <slot name="body">
              default body 
            </slot>
          </div>

          <div class="modal-footer">
            <slot name="footer">
              default footer
              <button class="modal-default-button" @click="$emit('close')">
                OK
              </button>
            </slot>
          </div>
        </div>
      </div>
    </div>
  </transition>
</script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make($viewpar['template'].'.backendVue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\workertime\resources\views/MOcalendarVue/calendarAdminSimple.blade.php ENDPATH**/ ?>