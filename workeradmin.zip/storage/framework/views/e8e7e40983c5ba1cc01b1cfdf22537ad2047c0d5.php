<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">


        <title>error</title>

    </head>
    <body>
        <div class="flex-center position-ref full-height">
   

            <div class="content">
              <?php echo e($error); ?>

            </div>
        </div>
    </body>
</html>
<?php /**PATH D:\laravel\workertime\resources\views/error.blade.php ENDPATH**/ ?>