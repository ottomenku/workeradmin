
                   <div class="row">    
                    <div class="col-xs-4"> 
                    <div class="input-group">  
                        <span  v-on:click="minusyear('<?php echo e($refreshTask); ?>')" style="cursor: pointer;" class="btn btn-outline-secondary input-sm"><</span>
                        <input id="year" size="2"  name="year" type="text" v-on:change="reFresh('<?php echo e($refreshTask); ?>')" v-bind:value="year" class="form-control input-sm ">
                        <span v-on:click="addyear('<?php echo e($refreshTask); ?>')" style="cursor: pointer;" class="btn btn-outline-secondary input-sm">></span>
                    </div>
                    </div> 

                    <div class="col-xs-2"> 
                        <select class="form-control input-sm " name="month" v-on:change="changeHo('<?php echo e($refreshTask); ?>')" v-model="month">
                            <option v-for="month in months" :value="month.value">{{ month.text }}</option>
                        </select>
                    </div>
                    <div class="col-xs-2"> 
                    <select class="form-control input-sm " v-on:change="selectDays()" name="select_action" id="select_action"  v-model="select_action">
                        <option v-for="(val, index) in checklist" :value="index">{{val}}</option>
                    </select>
                    </div>
                    </div>  
<?php /**PATH /home/www/pnet1408_drtjosep/public_html/workertime/resources/views/mocalendarVue/inc/actions_manager.blade.php ENDPATH**/ ?>