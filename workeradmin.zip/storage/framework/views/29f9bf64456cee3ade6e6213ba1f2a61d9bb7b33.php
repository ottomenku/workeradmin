<?php 

$months_magyar=['hónapok','Január','Február','Március','Április','Május','Június','Július','Augusztus','Szeptember','Október','November','Decenber'];
$months=$viewpar['calendar']['months'] ?? $months_magyar; unset($months[0]);// kiveszi az alapfeliratot és 1-el kezdődikaz index nem 0-val!!!!!
$template=$viewpar['template'] ?? 'admin_crudgenerator';
 ?>



<?php $__env->startSection('content'); ?>


<div  class="col-md-9">
    <div class="card">
        <div class="card-header"><?php echo e($viewpar['taskheader'] ?? $viewpar['app_name'] ?? $viewpar['route'] ?? 'index'); ?>

        </div>
        <div class="card-body"> 
                <br>

<!-- vue applikáció------------------------------------------------------>                     
<div id="app">
<!-- modal-------->
<modal v-if="showModal" @close="showModal = false">
       
        
<div slot="body">    <a class="btn btn-primary" v-bind:href="host+'pdf/'+storedid" >Letöltés </a>

    <div>munkanapok : {{solver.sumWorkerdays}}  </div>  
    <div class="" v-for="(wday, dkey) in solver.days">  
         {{dkey}}:  {{wday.days}} , összesen: {{wday.sumdays}}
    </div>
    <div class="" v-for="(wtime, tkey) in solver.times">  
     {{tkey}}:  {{wtime.hours}} , összesen: {{wtime.sumhours}}
    </div>

            <section class="th">
                            
                <span>Hétfő</span>
                <span>Kedd</span>
                <span>Szerda</span>
                <span>Csütörtök</span>
                <span>Péntek</span>
                <span>Szombat</span>
                <span>Vasárnap</span>
            </section>
            <div class="week" v-for="(week, weekindex) in storedToShow.calendar">      
                <div  v-bind:class="item.class" v-for="(item, datum) in week" v-bind:data-date="item.day"> 
                    <div  class="dayheader" v-if="item.name !== 'empty'">
                       
                        <span v-if="typeof basedays[datum] !== 'undefined'" class="dayhead" > 
                            {{basedays[datum]}}
                        </span>
                    </div>    
                <div class="daynumber" > {{item.day}} </div>                 
                <div v-if="typeof(storedToShow.workerdays.datekey[workerid])  !== 'undefined'" >
                    <div  v-bind:class="[workerdays.class]" v-for="workerdays in storedToShow.workerdays.datekey[workerid][datum]" >
                        {{workerdays.daytype.name}} 
                             
                    </div> 
                </div>  
                <div  v-if="typeof(storedToShow.times.datekey[workerid]) !== 'undefined'" >      
                    <div  v-bind:class="[time.class]"  v-for="(time) in storedToShow.times.datekey[workerid][datum]" >
                        {{time.start.substring(0,5)}}- {{time.end.substring(0,5)}}         
                       
                    </div>
                </div> 
                </div> 
            </div> 



</div>

    </modal>
    <!-- funkció gombok -------------------------------------------------->

                   <div class="row">    
                    <div class="col-xs-4"> 
                    <div class="input-group">  
                        <span  v-on:click="minusyear()" style="cursor: pointer;" class="btn btn-outline-secondary input-sm"><</span>
                        <input id="ev" size="2"  name="ev" type="text" v-on:change="changeEv()" v-bind:value="ev" class="form-control input-sm ">
                        <span v-on:click="addyear()" style="cursor: pointer;" class="btn btn-outline-secondary input-sm">></span>
                    </div>
                    </div> 

                    <div class="col-xs-2"> 
                        <select class="form-control input-sm " name="ho" v-on:change="changeHo()" v-model="ho">
                            <option v-for="mounth in mounths" :value="mounth.value">{{ mounth.text }}</option>
                        </select>
                    </div>
                    <div class="col-xs-2"> 
                    <select class="form-control input-sm " name="timetype_id"  v-model="actchecklist">
                        <option v-for="(val, index) in checklist" :value="index">{{val}}</option>
                    </select>
                    </div>
                    </div>  

    <!-- stored ---------------------------------------------------------------------->        

        <div class="table-responsive">
            <table class="table table-borderless">
                <thead>
                    <tr>
                       <th>Dolgozó</th><th>Zárás név</th><th>zárva</th><th>készült</th><th>frissítve</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>      
                    <tr v-for="(stored, key) in storeds">
                                             
                        <td>{{stored.worker.workername}}</td><td>{{stored.name}}</td><td> {{stored.lezarva}}</td>
                        <td> {{stored.created_at}} </td><td> {{stored.updated_at}} </td>
                        <td>
                            <i v-if="stored.lezarva==0" style="color:blue;size:2x;"  v-on:click="zarStored(key)"class="fa fa-unlock-alt"></i>
                            <i v-if="stored.lezarva==1" style="color:gray;size:2x;" class="fa fa-lock"></i>
                            <i style="color:blue;size:2x;"  v-on:click="showStored(key)"class="fa fa-eye"></i> 
                        </td>                 
                   
                    </tr>
                      
             
                </tbody>
            </table>
            </div>                      

</div>
</div>
</div>
</div>

<!-- template for the modal component -->
<script type="text/x-template" id="modal-template">
  <transition name="modal">
    <div class="modal-mask">
      <div class="modal-wrapper">
        <div class="modal-container">

          <div class="modal-header">
            <slot name="header">
                <button class="modal-default-button" @click="$emit('close')">
                   bezárás
                  </button>
            </slot>
          </div>

          <div class="modal-body">
            <slot name="body">
              default body 
            </slot>
          </div>

          <div class="modal-footer">
            <slot name="footer">
              default footer
              <button class="modal-default-button" @click="$emit('close')">
                OK
              </button>
            </slot>
          </div>
        </div>
      </div>
    </div>
  </transition>
</script>



<?php $__env->stopSection(); ?>


<?php echo $__env->make($template.'.backendVue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\workertime\resources\views/MocalendarVue/calendarAdminStored.blade.php ENDPATH**/ ?>