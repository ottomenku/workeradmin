<?php $__env->startSection('content'); ?>

<div style="margin:5%">   <center><h3>Dokumentum  generálás</h3> </center>

    <form id="editform" method="post" action="/m/ad.man.doc.doctemplate/preview" target="_blank">
      <button type="submit"  class="btn btn-primary" value="Submit"> Előnézet</button>  
      <button class="btn btn-primary" onclick="kuldment()" value="mentés">Mentés</button><br>

   <div class="row">
     <div class="col-md-6">
        <label class="control-label" for="name">azonosító</label>
        <input type="text" class="form-control"  name="name"> 
     </div>
      
     <div class="col-md-6">
        <label class="control-label" for="note">Megjegyzés</label>
        <input type="text" class="form-control"  name="note"> 
    </div>
    <div class="col-md-12">
      <label class="control-label" for="workerids">Dolgozók kiválasztása:</label><br>
      <?php $__currentLoopData = $data['workers'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div style=" align-items: stretch; border: 1px solid gray; float:left;padding:5px; margin:5px;" >              
          <div >   
                <input  type="checkbox" name="workerids[]" value="<?php echo e($worker->id); ?>">        
                <?php echo e($worker->workername); ?>               
          </div>
      </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
   </div>
      
     
      <textarea id="summernote" name="editordata"></textarea>
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    </form>
    <div style="display:none;">
     <ul class="workerattribute d-none" style="cursor: pointer;">
        <li data-value="<<['worker']['name']>>">Név</li>
        <li data-value="<<['worker']['user']['email']>>">Email</li>
        <li data-value="<<['worker']['fullname']>>">Teljes név</li>
        <li data-value="<<['worker'][position'']>>">Beosztás</li>
        <li data-value="<<['worker']['workername']>>">Egyesi név</li>
        <li data-value="<<['worker']['mothername']>>">Anyja neve</li>
        <li data-value="<<['worker']['city']>>">Lakhely (város)</li>
        <li data-value="<<['worker']['cim']>>">Cím</li>
        <li data-value="<<['worker']['tel']>>">Tel</li>
        <li data-value="<<['worker']['birth']>>">Születési idő</li>
        <li data-value="<<['worker']['birthplace']>>">Születési hely</li>  
        <li data-value="<<['worker']['ado']>>">Adószám</li>  
        <li data-value="<<['worker'][tb'']>>">TB szám</li>  
        <li data-value="<<['worker']['start]>>">Munkaviszony kezdete</li> 
        <li data-value="<<['worker']['start]>>">Munkaviszony vége</li> 

    </ul> 
    
Teljes szövegek	


birth
birthplace
ado
tb
end
start
    <ul class="cegattribute d-none" style="cursor: pointer;">
        <li data-value="<<['ceg']['cegnev']>>">cégnév</li>
        <li data-value="<<['ceg']['adoszam']>>">Adószám</li>
        <li data-value="<<['ceg']['ugyvezeto']>>">Ügyvezető</li>
        <li data-value="<<['ceg']['szekhely']>>">Székhely (város)</li>    	
       <li data-value="<<['ceg']['cim']>>">cím</li>
    </ul>
    </div>
  </div> 
    <script>    
    var workerDataInsert = function (context) {
        var ui = $.summernote.ui;
      
        var event = ui.buttonGroup([
            ui.button({
                contents: 'Dolgozói adatok beszúrása <i class="fa fa-caret-down" aria-hidden="true"></i><span class="caret"></span>',
              //  tooltip: 'When you insert',
                data: {
                    toggle: 'dropdown'
                }
            }),
            ui.dropdown({
                className: 'drop-default summernote-list cp',
                contents: $('.workerattribute').html(),
                callback: function ($dropdown) {                    
                    $dropdown.find('li').each(function () {
                        $(this).click(function () {  
                      $('#summernote').summernote('editor.restoreRange');
                        $('#summernote').summernote('editor.focus');
                           $('#summernote').summernote('editor.insertText', $(this).data('value'));
                       // $('#summernote').summernote('editor.insertText', 'fghsghsghg');

                        });
                    });
                }
            })
        ]);        

        return event.render();    // return button as jquery object
      }
      var cegDataInsert = function (context) {
        var ui = $.summernote.ui;
      
        var event = ui.buttonGroup([
            ui.button({
                contents: 'Cég adatok beszúrása <i class="fa fa-caret-down" aria-hidden="true"></i><span class="caret"></span>',
              //  tooltip: 'When you insert',
                data: {
                    toggle: 'dropdown'
                }
            }),
            ui.dropdown({
                className: 'drop-default summernote-list cp',
                contents: $('.cegattribute').html(),
                callback: function ($dropdown) {                    
                    $dropdown.find('li').each(function () {
                        $(this).click(function () {  
                      $('#summernote').summernote('editor.restoreRange');
                        $('#summernote').summernote('editor.focus');
                           $('#summernote').summernote('editor.insertText', $(this).data('value'));
                       // $('#summernote').summernote('editor.insertText', 'fghsghsghg');

                        });
                    });
                }
            })
        ]);        

        return event.render();    // return button as jquery object
      }
      var preview = function (){
        
        var dataString =  $("#summernote").html();
        
        $.ajax({
          type: "POST",
          url: "/m/ad.man.doc.doctemplate/create",
          data: {
            "html": dataString,
            "_token": "<?php echo e(csrf_token()); ?>"
          },
          success: function(datas) {
            var w = window.open('about:blank');
            w.document.open();
            w.document.write(datas);
            w.document.close();
        },
        error: function(jqXHR) {
            showError("...");
        }
         /* success: function() {
            $('#form').html("<div id='message'></div>");
            $('#message').html("<h2>Message Submitted.</h2>")
            .append("<p>Thank you for contacting me, I will be in touch soon.</p>")
            .hide()
            .fadeIn(1500);
          }*/
        });
        return false;
        
        }
    </script> 
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_crudgenerator.docs.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ujworkertime\workeradmin\resources\views/admin_crudgenerator/docs/general.blade.php ENDPATH**/ ?>