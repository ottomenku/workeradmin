

<?php $__env->startSection('content'); ?>
<?php
 $tableinclude= $viewpar['tableinclude'] ?? 'includes.table.table_old'; 
?>
<div class="col-md-9">
    <div class="card">
        <div class="card-header"><?php echo e($viewpar['taskheader'] ?? $viewpar['app_name'] ?? $viewpar['route'] ?? 'index'); ?></div>
        <div class="card-body">
         <?php if($viewpar['createbutton'] ?? true): ?>   
            <a href="<?php echo e(url($viewpar['route'].'/create')); ?>" dusk="new" class="btn btn-success btn-sm" title="Uj dokumentum kategória">
                <i class="fa fa-plus" aria-hidden="true"></i> Add New
            </a>
        <?php endif; ?>    
        <?php if(isset($viewpar['info'])): ?>       
        <div  class="float-right">
            <a href="#myModalInfo"   data-toggle="modal" data-content="modalInfobody"> <i style="color:blue;font-size:2rem;" class="fa fa-info-circle" aria-hidden="true"></i></a>
        </div>          
        <?php endif; ?> 
        <?php if($viewpar['searchbox'] ?? false): ?>   
            <?php echo Form::open(['method' => 'GET', 'url' => url($viewpar['route']), 'class' => 'form-inline my-2 my-lg-0 float-right', 'role' => 'search']); ?>

            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Search..." value="<?php echo e(request('search')); ?>">
                <span class="input-group-append">
                    <button class="btn btn-secondary" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
            <?php echo Form::close(); ?>

            <?php endif; ?> 
            <?php if($viewpar['tableform'] ?? false): ?>

            <?php $formroute= $viewpar['formroute'] ?? $viewpar['route']; ?>
            <?php echo Form::open(['method' => 'POST', 'url' => $formroute, 'class' => 'form-inline my-2 my-lg-0 float-right', 'role' => 'search']); ?>

            <br/> 
            <button class="btn btn-outline-<?php echo e($viewpar['gomb1,']['class'] ?? 'success'); ?> button-xs" value="<?php echo e($viewpar['gomb1']['val'] ?? 'pub'); ?>" type="submit"><?php echo e($viewpar['gomb1']['label'] ?? 'A kijelöltek engedélyezése'); ?></button>
            <button class="btn btn-outline-<?php echo e($viewpar['gomb2,']['val'] ?? 'danger'); ?>" value="<?php echo e($viewpar['gomb2,']['val'] ?? 'unpub'); ?>" type="submit"><?php echo e($viewpar['gomb2']['label'] ?? 'A kijelöltek tiltása'); ?></button>
            <div class="btn btn-outline-<?php echo e($viewpar['gomb2,']['val'] ?? 'danger'); ?>" ><input type="checkbox" id="checkAll" name="checkAll"><?php echo e($viewpar['gomb2']['label'] ?? 'összes kijelölése'); ?></div>
            <?php endif; ?>
            <br/>
<!-- table --------------------------------------------->            

<?php echo $__env->make($tableinclude, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- table --------------------------------------------->  

                <div class="pagination-wrapper"> </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php 
//dump($data);
//dump($data['tabledata'][0]['email']);
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($viewpar['template'].'.'.$viewpar['frame'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/pnet1408_drtjosep/public_html/workertime/resources/views/baseTaskviews/index.blade.php ENDPATH**/ ?>