<?php             
   $menuT= $viewpar['menu'] ?? [];
   $timemenu= $viewpar['timemenu'] ?? false;
 //  $menuT['superadmin'][]=['/admin/generator'=>' Generátor'];
 ?>             

 <?php if( $timemenu): ?>
    <?php echo $__env->make('admin_crudgenerator.timemenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php else: ?>
 <div class="col-md-3">
    <?php if(Auth::id()>0): ?>
    <?php if(Auth::user()->hasRole('superadmin')): ?> 

   <div class="card">
        <div class="card-header">
            Szuperadmin menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['superadmin'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>   
        </div>  
    </div>    
    <?php endif; ?> 
    <?php if(Auth::user()->hasRole('admin')): ?> 

   <div class="card">
        <div class="card-header">
            Admin menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['admin'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  

    </div>    
<?php endif; ?> 
<?php if(Auth::user()->hasRole('manager')): ?> 
<?php             
   $doctemplate=new App\Doctemplate();
   $docmenuT=$doctemplate->getMenu(); 
 ?>  
   <div class="card">
        <div class="card-header">
            Manager menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['manager'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  
        <div class="card-header">
          Dokumentum generálás
        </div>
        <?php $__currentLoopData = $docmenuT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat=>$menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
        <div class="card-header" style="color:rgb(61, 114, 211)">
           <?php echo e($cat); ?>

        </div>
        <div >
            
            <ul >
                <?php $__currentLoopData = $menus ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a class="nav-link" href="/m/ad.man.docgeneral/create/<?php echo e($menu['id']); ?>">
                        <?php echo e($menu['name']); ?>

                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>  
<?php endif; ?> 

<?php if(Auth::user()->hasRole('worker')): ?> 

   <div class="card">
        <div class="card-header">
            Dolgozói menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['worker'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  
    </div>    
<?php endif; ?>  
<?php endif; ?>  
<?php endif; ?> 
</div>
        
<?php /**PATH C:\ujworkertime\workeradmin\resources\views/admin_crudgenerator/sidebar.blade.php ENDPATH**/ ?>