<?php             
   $menuT=[
    'superadmin'=>[],
    'admin'=>[
        1 => ['m/ad.ad.ceg', 'Cégek'],
        2 => ['m/ad.ad.timetypes', ' Időtipusok'],
        3 => ['m/ad.ad.daytypes', ' Natipusok'],
        4 => ['m/ad.ad.basedays', 'Naptár'],
        5 => ['/', ' Home'],
    ],
    
    ];
   $menuT= $viewpar['menu'] ?? $menuT;
 //  $menuT['superadmin'][]=['/admin/generator'=>' Generátor'];
 ?>             
 <div class="col-md-3">
<?php if(Auth::id()>0): ?>
  <?php if(Auth::user()->hasRole('superadmin')): ?> 

   <div class="card">
        <div class="card-header">
            Szuperadmin menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['superadmin'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  
    </div>    
<?php endif; ?> 
<?php if(Auth::user()->hasRole('admin')): ?> 

   <div class="card">
        <div class="card-header">
            Admin menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['admin'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  
        <div class="card-header">
           Zárások
        </div>
<?php
    $cegs=App\Ceg::where('pub','>',0)->get(); 
?>

        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
             <?php $__currentLoopData = $cegs ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ceg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li class="nav-item" role="presentation">
                <a class="nav-link" href="<?php echo e(url('/m/ad.time.admin/getceg/'.$ceg->id)); ?>">
                    <?php echo e($ceg->cegnev); ?>

                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div> 
    </div>    
<?php endif; ?> 
<?php if(Auth::user()->hasRole('manager')): ?> 

   <div class="card">
        <div class="card-header">
            Manager menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['manager'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  
    </div>    
<?php endif; ?> 
<?php if(Auth::user()->hasRole('workadmin')): ?> 

   <div class="card">
        <div class="card-header">
            Workadmin menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['workadmin'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  
    </div>    
<?php endif; ?> 
<?php if(Auth::user()->hasRole('worker')): ?> 

   <div class="card">
        <div class="card-header">
            Dolgozói menü
        </div>
        <div class="card-body">
            <ul class="nav flex-column" role="tablist">
                <?php $__currentLoopData = $menuT['worker'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" href="<?php echo e(url($menu[0])); ?>">
                        <?php echo e($menu[1]); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>  
        </div>  
    </div>    
<?php endif; ?>  
<?php endif; ?>  

</div>
        
<?php /**PATH /home/www/pnet1408_drtjosep/public_html/workertime/resources/views/admin_crudgenerator/sidebar.blade.php ENDPATH**/ ?>