<style>
        .weekness{
        color:red;
        border: 1px solid red; 
        }
        .workday{
        color:silver;
        border: 1px solid silver; 
        }
        .flex-container {
            padding: 0;
            margin: 0;
            width: 100%;
            list-style: none;
            justify-content:flex-end;
            -ms-box-orient: horizontal;
            display: -webkit-box;
            display: -moz-box;
            display: -ms-flexbox;
            display: -moz-flex;
            display: -webkit-flex;
            display: flex;
          }
          .nowrap  { 
            -webkit-flex-wrap: nowrap;
            flex-wrap: nowrap;
          }
        
          .flex-item { 
            background: white;
            padding: 5px;
            width: 13.7%;
           /* height: 100px;*/
            margin: 0.3%;
            text-align: center;
            overflow:hidden;
          }
        .wishcolor{color:red;}
        .acceptcolor{color:green;}
        .wishbase{color:grey;}
        </style><?php /**PATH H:\laravel\workertime\resources\views/MOcalendar/style.blade.php ENDPATH**/ ?>