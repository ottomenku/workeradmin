<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?> </title> 
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <?php
    $solver=$data['solver'];
    $workerid=$data['workerid'] ;
    $fulldata=$data['fulldata'];
    $times= $fulldata['times']['datekey'][$workerid] ?? [];
    $workerdays= $fulldata['workerdays']['datekey'][$workerid] ?? [];
  
  ?>

</head>
<body>
    <main class="py-4">

        <div class="container" dusk="category.index" >
            <div class="row">
 

                <div  class="col-md-9">
                    <div class="card">
                        <div class="card-header"> Header  </div>
                        <div class="card-body"> 
                                         
                            <div>munkanapok : <?php echo e($solver['sumWorkerdays']); ?>  </div>  
                            <?php $__currentLoopData = $solver['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dkey=> $wday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">  
                                    <?php echo e($dkey); ?>:  <?php echo e(implode(',',$wday['days'])); ?> , összesen: <?php echo e($wday['sumdays']); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $solver['times']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkey=> $wtime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="">  
                                <?php echo e($tkey); ?>:  <?php echo e(implode(',',$wtime['hours'])); ?> , összesen: <?php echo e($wtime['sumhours']); ?>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                    
                        <section class="th">
                                        
                            <span>Hétfő</span>
                            <span>Kedd</span>
                            <span>Szerda</span>
                            <span>Csütörtök</span>
                            <span>Péntek</span>
                            <span>Szombat</span>
                            <span>Vasárnap</span>
                        </section>

                        <?php $__currentLoopData = $fulldata['calendar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekindex=> $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <div class="week" >      
                            <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div  class="dayheader" >
                             <!--   <span  class="dayhead" > basedays.datum </span> -->
                            <div class="daynumber" > <?php echo e($item['day']); ?> </div> 
                            <?php if(isset($workerdays[$datum])): ?>
                                <?php $__currentLoopData = $workerdays[$datum]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>         
                                    <div  class="<?php echo e($workerday['class']); ?>" >
                                        <?php echo e($workerday['daytype']['name']); ?> 
                                            
                                    </div>     
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>  
                              <?php if(isset($times[$datum])): ?>
                                <?php $__currentLoopData = $times[$datum]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div  class="<?php echo e($time['class']); ?>" >
                                    <?php echo e(substr($time['start'],0,5)); ?>- <?php echo e(substr($time['end'],0,5)); ?>        
                                </div>    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                <?php endif; ?>  
                               </div>     
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      
                                   


                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </main>
</body>
</html>
<?php /**PATH D:\laravel\workertime\resources\views/pdf.blade.php ENDPATH**/ ?>