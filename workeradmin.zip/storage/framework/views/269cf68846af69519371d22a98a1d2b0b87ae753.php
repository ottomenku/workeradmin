<?php
 /*if(isset($data['formdata'])){
     $formdata=$data['formdata'];
   $data=$formdata;
   print_r($data);
    }*/
$base_par=[
'labelpar'=>['class' => 'col-md-4 control-label'],
'inputpar'=>['class' => 'form-control'], 
'formcreatepar'=>[ 'class' => 'form-horizontal', 'files' => true], //url a parméterben kell megadni vagy generál aroutból
'formeditpar'=>[ 'method' => 'PATCH','class' => 'form-horizontal', 'files' => true], 
'submit_class'=>'btn btn-primary', 
]; // helyi alap változók, a controllerel átadott $viewpar felülírja

 //be kell írni a composr.json-ba  "autoload": { "files": ["packages/ottomenku/laravel-mocontroller/src/helper.php" ]
// vagylétre kell hzni a \vendor\laravel\framework\src\Illuminate\Foundation\helpers.php-ban
$conf=setconf($base_par,$viewpar,'tpar'); //be kell másolni és mergelni a paramétereket a confba hogy a config()-al lehessen elérni, és ne kelljen vele foglalkozni hogy van e olyan kulc illetve könnyú alap alapértéket adni

$value = array_get($base_par, 'names.john', 'default'); //dot tömbelérés defaultal
?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9">
    <div class="card">
       
        <div class="card-header">  <?php echo e($viewpar['taskheader'] ?? 'Szerkesztés'); ?></div>
        <div class="card-body">
                <a href="<?php echo e(url($viewpar['route'])); ?>" title="Back"><button class="btn btn-warning btn-sm">
                    <i class="fa fa-arrow-left" aria-hidden="true"></i> Vissza</button>
                </a>
                     
            <br/>
            <br/>
                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <?php if(isset($viewpar['info'])): ?>       
                        <div  class="float-right">
                            <a href="#myModalInfo"   data-toggle="modal" data-content="modalInfobody"> <i style="color:blue;font-size:2rem;" class="fa fa-info-circle" aria-hidden="true"></i></a>
                        </div>          
                        <?php endif; ?>
            <?php
       $formend=true;
            ?>
            
            <?php $__currentLoopData = $viewpar['form']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name=>$param): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
            $func=$param[0] ; 
           // $name = explode('*',$name)[0]; //indexelés eltávolítása nem biztos hogy kell
              ?>     
                <?php switch($func):
                case ('html'): ?>
                <?php
                // 'tex1'=> ['html','tipus',['szöveg','id="tex1"'],
                $tipus=$param[1] ?? 'span'; 
                $content=$param[2][0] ?? '';  
                $param=$param[2][1] ?? '';
                ?> 
                <<?php echo e($tipus); ?> <?php echo e($param); ?>> <?php echo e($content); ?> </<?php echo e($tipus); ?>> 
                <?php break; ?>
                <?php case ('formstartCreate'): ?>
                <?php $url =$param['url'] ?? config('tpar.route').'/store';
                $formpar=$param[1] ?? [];  $formpar['url']=$url; $formend=$param[2] ?? $formend;  ?> 
               <?php echo Form::model($data,array_merge(config('tpar.formcreatepar',[]),$formpar)); ?>          
                <?php break; ?>

                <?php case ('formstartEdit'): ?>
                <?php $url =$param['url'] ?? config('tpar.route').'/update/'. config('tpar.id');
                $formpar=$param[1] ?? [];  $formpar['url']=$url; $formend=$param[2] ?? $formend;  ?> 
                <?php echo Form::model($data,array_merge(config('tpar.formeditpar',[]),$formpar)); ?>          
                <?php break; ?>
                <?php case ('formend'): ?>
                <?php echo Form::close(); ?>        
                <?php break; ?>
                <?php case ('submit'): ?>
                <input dusk="savebutton" class="<?php echo e($param['class'] ?? config('tpar.submit_class')); ?>" type="submit" value="<?php echo e($param[1] ?? 'Mentés'); ?>">      
                <?php break; ?>
                <?php default: ?>
                <?php
                $label=$param[1] ?? '' ;
                $labelp=$param[2]['labelpar'] ?? [];   
                $labelpar=array_merge(config('tpar.labelpar'),$labelp);
                ?>
                <div class="form-group <?php echo e($errors->has($name) ? 'has-error' : ''); ?>">                                                
                   
                    <?php echo Form::label($name, $label, $labelpar ); ?>

                 
                        <div class="col-md-6">    
                            <?php switch($func):
                                case ('htmlWithLabel'): ?>
                                <?php
                                // 'tex1'=> ['htmlWithLabel','label',['span','szöveg','id="tex1"'],
                                $tipus=$param[2][0] ?? 'span'; 
                                $content=$param[2][1] ?? '';  
                                $param=$param[2][2] ?? '';
                                ?> 
                              <<?php echo e($tipus); ?> <?php echo e($param); ?>> <?php echo e($content); ?> </<?php echo e($tipus); ?>>
                               <?php break; ?>

                                <?php case ('select'): ?>
                                 <?php
                                     $checked= $data[$name] ?? $param[3] ?? null;
                                     $inputp=$param[2]['inputpar'] ?? $param[2] ?? []; 
                                    $inputpar=array_merge(config('tpar.inputpar',[]),$inputp); 
                                 ?> 
                                <?php echo Form::select($name, $data[$name.'_list'], $checked, $inputpar); ?>   
                                <?php break; ?> 
                        <?php case ('filelist'): ?>
                            <?php if(isset($data[$name])): ?>   
                               <?php $__currentLoopData = $data[$name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span style="color:blue;">  <?php echo e($file->name); ?> 
                                    <a href="<?php echo e(url($viewpar['route']).'/destroyfile/'. $file->id); ?>" onclick="return confirm('Biztos hogy törölni akarja?')" title="törlés" class="btn btn-danger btn-sm">
                                         <i style="color:white;" class="fa fa-trash-o" aria-hidden="true"></i>
                                    </a>
                                </span></br>
                                   
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>  
                         <?php break; ?> 
                                 <?php case ('file'): ?>
                                  <?php echo Form::file($name); ?> 
                                <?php break; ?>  
                                <?php case ('image'): ?>
                                <?php if(isset($data[$param[1]])): ?>
                                 <img src=" <?php echo e($data[$param[1]]); ?>" width="50px" height="50px">   
                                <?php else: ?> 
                                <img src="/images/img_avatar.png" width="50px" height="50px">  
                                <?php endif; ?>
                                <?php echo Form::file($name); ?> 
                              <?php break; ?>   
                                <?php case ('checklist'): ?>
                                     <?php $__currentLoopData = $param[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     <?php 
                                     $listname=$checlist[0];
                                     $listvalue=$checlist[1];
                                     $listlabel=$checlist[2] ?? $listname;
                                     $listchecked= $checlist[3] ??  false;    
                                     if(isset($data[$listname]) && $data[$listname]==$listvalue ) { $listchecked=true; }
                                      ?> 
                                     <?php echo e(Form::checkbox($listname, $listvalue, $listchecked)); ?> <?php echo e($listlabel); ?>

                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php break; ?>
                        
                               <?php case ('checkgroup'): ?>
                               <?php $__currentLoopData = $param[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listval=> $listlabel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php 
                               $listname=$name.'[]';
                              // $listvalue=$checlist[0];
                              // $listlabel=$checlist[1] ?? $listname;
                                $listchecked= false;    
                               if(isset($data[$listname]) && $data[$listname]==$listval ) { $listchecked=true; }
                               ?> 
                               <?php echo e(Form::checkbox($listname, $listval, $listchecked)); ?> <?php echo e($listlabel); ?>

                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php break; ?>

                            <?php case ('check'): ?> 
                                <?php 
                                $value=$param[2] ;
                                $label=$param[1] ?? $name; 
                                $dataval=$data[$name] ?? '';
                                $checked= false;
                                if(!isset($data[$name])){$checked= $param[3] ?? false;}
                                if($value==$dataval){ $checked= true;}
                                ?> 
                              <?php echo e(Form::checkbox($name, $value, $checked)); ?> <?php echo e($label); ?>

                            <?php break; ?>
                            <?php case ('radio'): ?>
                              <?php 
                              $value=$param[2] ;
                              $label=$param[1] ?? $name; 
                              $dataval=$data[$name] ?? '';
                              $checked= false;
                              if(!isset($data[$name])){$checked= $param[3] ?? false;}
                              if($value==$dataval){ $checked= true;}
                              ?> 
                              <?php echo e(Form::radio($name, $value, $checked)); ?> <?php echo e($label); ?>

                            <?php break; ?>
                            
                               <?php case ('radiolist'): ?>
                               <?php $__currentLoopData = $param[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php 
                               $listname=$name;
                               $listvalue=$checlist[0];
                               $listlabel=$checlist[1] ?? '';
                               $listchecked= $checlist[2] ??  false;    
                               if(isset($data[$listname]) && $data[$listname]==$listvalue ) { $listchecked=true; }
                                ?> 
                                <?php echo e(Form::radio($listname, $listvalue, $listchecked)); ?> <?php echo e($listlabel); ?>

                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php break; ?>               
         
                                <?php default: ?>
                                <?php 
                                $inputp=$param[2]['inputpar'] ?? $param[2] ?? []; 
                               // $valuefinal=$data[$name] ?? null;
                                $inputpar=array_merge(config('tpar.inputpar',[]),$inputp); 
                                ?>
                                 <?php echo Form::$func($name,null , $inputpar); ?>

                            <?php endswitch; ?>         
                         
                        <?php echo $errors->first($name, '<p class="help-block">:message</p>'); ?> 
                    </div>     
                </div>
            <?php endswitch; ?>                        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
            <?php if($formend): ?>  <?php echo Form::close(); ?>  <?php endif; ?>    
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make($viewpar['template'].'.'.$viewpar['frame'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/www/pnet1408_drtjosep/public_html/workertime/resources/views/baseTaskviews/baseform_include.blade.php ENDPATH**/ ?>