<?php 

$months_magyar=['hónapok','Január','Február','Március','Április','Május','Június','Július','Augusztus','Szeptember','Október','November','Decenber'];
$months=$viewpar['calendar']['months'] ?? $months_magyar; unset($months[0]);// kiveszi az alapfeliratot és 1-el kezdődikaz index nem 0-val!!!!!
$template=$viewpar['template'] ?? 'admin_crudgenerator';
?>



<?php $__env->startSection('content'); ?>


<div  class="col-md-9">
    <div class="card">
        <div class="card-header"><?php echo e($viewpar['taskheader'] ?? $viewpar['app_name'] ?? $viewpar['route'] ?? 'index'); ?>

        </div>
        <div class="card-body"> 
                <br>
<style>
  .difminusz{ color:red;}
  .difplusz{ color:green;}    
</style>
<!-- vue applikáció--------------------------->                     
<div id="app">

<!-- modal button----------------------------->
<div  class="float-right"><i style="color:blue;font-size:2rem;"
        v-on:click="showModalInfo()"class="fa fa-info-circle"></i> 
</div>


<!-- modal info------------------------------->
  <modal v-if="showInfo" @close="showInfo = false">    
  <div slot="body">  
  info szöveg
  </div>
  </modal>

<!-- modal--------------------------------------->
    <modal v-if="showModal" @close="showModal = false">    
    <div slot="body">  
    <?php echo $__env->make('mocalendarVue.inc.solver', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    </modal>
<!--  panel---------------------------------------->                 
      <div class="container">
      <ul class="nav nav-tabs nav-justified">
      <li class="nav-item">
          <a class="nav-link" @click.prevent="setAdminActive('stored')" :class="{ active: isAdminActive('stored') }" href="#stored">Zárások</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" @click.prevent="setAdminActive('timeframe')" :class="{ active: isAdminActive('timeframe') }" href="#newform">Időkeret</a>
        </li>

      </ul>        
    <div class="tab-content py-3" id="myTabContent">
    <div class="tab-pane fade" :class="{ 'active show': isAdminActive('stored') }" id="stored">
    
<!-- funkció gombok ---------------------------------->
      <?php echo $__env->make('mocalendarVue.inc.ev_ho',['refreshTask' => "stored"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- stored ------------------------------------------>        
       <?php echo $__env->make('mocalendarVue.inc.stored_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </div>
      <div class="tab-pane fade" :class="{ 'active show': isAdminActive('timeframe') }" id="timeframe">
  <?php echo $__env->make('mocalendarVue.admin.inc.timeframe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
<!-- stored -------------------------------------------->
     

</div>  
</div> 







 

  
</div>
</div>
</div>
</div>

<!-- modal template -------------------------------------------------->
<?php echo $__env->make('mocalendarVue.inc.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make($template.'.backendVue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\workertime\resources\views/MocalendarVue/admin/calendarAdminStored.blade.php ENDPATH**/ ?>