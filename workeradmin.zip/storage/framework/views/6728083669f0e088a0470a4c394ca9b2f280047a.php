<div class="col-md-3">

  <div class="card">
    <div class="card-header">
      <a class="nav-link" href="#"><< Nyitólap </a>
      
    </div>
  </div> </br> 
    <ul class="nav nav-tabs" id="myTab" role="tablist">

      <li class="nav-item waves-effect waves-light">
            <a class="nav-link active" id="contact-tab" data-toggle="tab" href="#contact" role="tab"
              aria-controls="contact" aria-selected="true">Napok</a>
      </li>
      <li class="nav-item waves-effect waves-light">
            <a class="nav-link " id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile"
              aria-selected="false">Munkaidők</a>
      </li>

    </ul>
    <div class="tab-content" id="myTabContent">
      <div class="tab-pane fade active show" id="contact" role="tabpanel" aria-labelledby="contact-tab">
              <!-- napok form   https://fontawesome.com/v4.7.0/icons/ --------------------------------->
        <div class="row">
              <label for="daytype_id" class="col-3 control-label">Naptipus</label>

        </div>
        <div class="row">
                <?php
                $checked="";
                ?>
                <?php $__currentLoopData = $data['daytypes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daytype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-11">
                  <?php
                  $color=$daytype['color'] ?? 'gray';
                  $bgcolor='';
                  $hourcolor=$daytype['timetype']['color'] ?? 'gray';
                  $hourbgcolor='';
                  if(isset($daytype['background'])) {$bgcolor= ' background-color:'.$daytype['background'].';';}
                  if(isset($daytype['timetype']['background'])) {$hourbgcolor= '
                  background-color:'.$daytype['timetype']['background'].';';}
                  ?>
                  <input type="radio" name="daytype_id" value="<?php echo e($daytype['id']); ?>" <?php echo e($checked); ?>>
                  <span>
                    <i style="font-size:1.2em; color:<?php echo e($color); ?>; <?php echo e($bgcolor); ?> " class="fa fa-<?php echo e($daytype['icon'] ?? ''); ?>"
                      aria-hidden="true"></i>
                    <?php echo e($daytype['name'] ?? ''); ?>,
                    <span
                      style="font-size:1.2em; color:<?php echo e($hourcolor); ?>; <?php echo e($hourbgcolor); ?>"><?php echo e($daytype['timetype']['basehour'] ?? '0'); ?>

                      óra
                    </span>
                    </label>
            </div>
   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
            <div class="row">
                  <label for="dayadnote" class="col-3 control-label">megjegyzés</label>

            </div>
            <div style="margin-left: 0px;" class="row">
                <div class="col-11">
                    <input class="form-control" name="dayadnote" type="text" id="dayadnote">
                </div>
            
                <button class=" btn btn-primary" v-on:click="storedays()" style="margin:2px;">
                  <i class="fa fa-save"></i>
                </button>
                <button class=" btn btn-danger" v-on:click="daysreset()" style="margin:2px;">
                  <i class="fa fa-trash"></i>
                </button>
                <a href="m/ad.man.timetype/create" class=" btn btn-succes" style="margin:2px;">
                  <i class="fa fa-plus">Új naptipus</i>
                </a>
                <!--  napok form  end --------------------------------->
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">

            <div class="row">


              <div style=" padding-left: 5px; padding-right: 0;" class="col-8">
                  <label for="hour" class="col-11 control-label">Óra </label>

                  <input class="form-control" name="hour" type="number" id="hour"
                    value="<?php echo e(array_values($data['timetypes'])[0]['basehour']); ?>">

              </div>
              <div class="col-3">
                  <label for="hour" class="col-11 control-label">- </label>
                  <button class="btn btn-primary" data-toggle="collapse" data-target="#collapseExample">
                    +
                  </button>
              </div>
              <div class="collapse" id="collapseExample">

                  <div class="row">
                    <div class="col-11">
                      <label for="start" class="col-11 control-label">Kezdés </label>
                      <input class="form-control" name="start" type="time" id="start"
                        value="<?php echo e(array_values($data['timetypes'])[0]['start']); ?>">
                    </div>
                    <div class="col-11">
                      <label for="end" class="col-11 control-label">Befejezés </label>
                      <input class="form-control" name="end" type="time" id="end"
                        value="<?php echo e(array_values($data['timetypes'])[0]['end']); ?>">
                    </div>
                    <div class="col-11">
                      <label for="timeadnote" class="col-11 control-label">Megjegyzés </label>
                      <input class="form-control" name="timeadnote" type="text" id="timeadnote">
                    </div>
                  </div>
                </div>
                <div style=" padding-left: 5px; padding-right: 20;" class="col-11">

                  <?php $__currentLoopData = $data['timetypes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$timetype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="col-11">
                    <?php
                    $checked='';
                    if($timetype['id']== array_values($data['timetypes'])[0]['id'])
                    {$checked=' checked ';}
                    $color=$timetype['color'] ?? 'gray';
                    $bgcolor='';
                    if(isset($timetype['background'])) {$bgcolor= ' background-color:'.$timetype['background'].';';}
                    ?>



                    <span
                      onclick="hourToInput('<?php echo e($timetype['basehour']); ?>','<?php echo e($timetype['start']); ?>','<?php echo e($timetype['end']); ?>')"
                      style="font-size:1.3em; color:<?php echo e($color); ?>; <?php echo e($bgcolor); ?>">
                      <input type="radio" name="timetype_id" value="<?php echo e($timetype['id']); ?>" <?php echo e($checked); ?>>
                      <?php echo e($timetype['name']); ?>, <?php echo e($timetype['basehour'] ?? '0'); ?> óra

                    </span>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <div style="margin-left: 0px;" class="row">
                <button class=" btn btn-primary" v-on:click="storetimes()" style="margin:2px;">
                  <i class="fa fa-save"></i>
                </button>
                <button class=" btn btn-danger" v-on:click="timesreset()" style="margin:2px;">
                  <i class="fa fa-trash"></i>
                </button>
                <a href="m/ad.man.timetype/create" class=" btn btn-succes" style="margin:2px;">
                  <i class="fa fa-plus">Új időtipus</i>
                </a>
              </div>
              </div>
            </div>
            </div>

          
  </div>       <?php /**PATH C:\ujworkertime\workeradmin\resources\views/admin_crudgenerator/timemenu.blade.php ENDPATH**/ ?>