<?php
  $b='lllllllll';
?>
<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'MOworktime')); ?> </title>

<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<?php
$now=$now =Carbon\Carbon::now();
$year=$data['year'] ?? $now->year;
$month=$data['month'] ?? $now->month;
$viewparid = $viewpar['id'] ?? 0
?>
    <!-- eredetiből-->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
    <script>

        window.viewpar=<?php echo json_encode($viewpar ?? [], 15, 512) ?> ;
        window.viewparid=<?php echo e($viewparid); ?>; 
        window.year= <?php echo e($year); ?>;   
        window.month=<?php echo e($month); ?>;
        
        $( document ).ready(function() {

                $('#checkAll').click(function (event) {
                    if (this.checked) {
                        $('.checkbox').each(function () { //loop through each checkbox
                            $(this).prop('checked', true); //check 
                        });
                    } else {
                        $('.checkbox').each(function () { //loop through each checkbox
                            $(this).prop('checked', false); //uncheck              
                        });
                    }
                });
        $( "#datepicker" ).datepicker({ dateFormat: 'yy-mm-dd', changeYear: true,defaultDate: new Date()});
        $( "#datepicker2" ).datepicker({ dateFormat: 'yy-mm-dd', changeYear: true,defaultDate:+30}); 
          
  });
  
    </script>
</head>
<body>

    <div>
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <li><a href="<?php echo e(url('/admin')); ?>">Dashboard <span class="sr-only">(current)</span></a></li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li><a class="nav-link" href="<?php echo e(url('/login')); ?>">Login</a></li>
                            <li><a class="nav-link" href="<?php echo e(url('/register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(url('/logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php if(Session::has('flash_message')): ?>
                <div class="container">
                    <div class="alert alert-success">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                        <?php echo e(Session::get('flash_message')); ?>

                    </div>
                </div>
            <?php endif; ?>
            <?php if(Session::has('error_message')): ?>
            <div class="container">
                <div class="alert alert-danger">
                    <?php echo e(Session::get('error_message')); ?>

                </div>
            </div>
        <?php endif; ?>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="container" dusk="category.index" >
                <div class="row">

<!-- sidebar------------------------------------------------------->                    
<?php echo $__env->make('admin_crudgenerator.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- content------------------------------------------------------>    
<?php echo $__env->yieldContent('content'); ?>

            </div>
            </div>
        </main>
    </div>
   
 
    <script src="<?php echo e(mix('js/app.js')); ?>" type="text/javascript"></script>

</body>
</html>
<?php /**PATH /home/www/pnet1408_drtjosep/public_html/workertime_dev/resources/views/admin_crudgenerator/backendVue.blade.php ENDPATH**/ ?>