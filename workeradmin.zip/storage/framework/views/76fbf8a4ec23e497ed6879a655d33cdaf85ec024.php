<?php  
    $times=$data['times'] ?? [];
    $timetypes=$data['timetypes'] ?? [];
?> 

<ul class="nav nav-tabs">
        <li class="nav-item">
          <a class="nav-link " data-toggle="tab" href="#times">Idők</a>
        </li>
        <li class="nav-item">
            <a class="nav-link " data-toggle="tab" href="#days">Napok ( szabadság betegállomány  stb.)</a>
        </li>
</ul>


<!-- Tab panes -->
<div class="tab-content" >   
    <div id="times" class="container tab-pane active"><br>

  <div class="table-responsive">
                    <table class="table table-borderless">
                        <thead>
                            <tr>
                                <th>Start</th><th>End</th><th>Óraszám</th><th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->start); ?></td>
                                <td><?php echo e($item->end); ?></td><td><?php echo e($item->hour); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/admin/category/' . $item->id . '/edit')); ?>" dusk="edit<?php echo e($item->id); ?>" title="Edit Category"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>       
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>    
        </div>

        <hr>
                <?php echo Form::model($data,[
                   'method' => 'POST',
                'url' => ['/m/ad.wor.time/store'],
                'class' => 'form-horizontal',
                'files' => true  
                ]    
               ); ?>


                <div class="form-group <?php echo e($errors->has('timetype_id') ? 'has-error' : ''); ?>">
                  
                </div>
                    <?php echo Form::hidden('datum', $data['datum'] ?? ''); ?>

                    <div class="row">
                    <div class="col-4">            
                            <?php echo Form::label('timetype_id', 'Időtipus', ['class' => 'col-4 control-label']); ?>         
                            <?php echo Form::select('timetype_id', $data['timetype_id_list'], null, ['class' => 'form-control']); ?>   
                            <?php echo $errors->first('timetype_id', '<p class="help-block">:message</p>'); ?>   
                    </div>    
                        <div class="col-8">
                            <?php echo Form::label('time_workernote', 'Megjegyzés', ['class' => 'col-8 control-label']); ?>

                            <?php echo Form::text('time_workernote', null, ['class' => 'form-control']); ?>

                            <?php echo $errors->first('time_workernote', '<p class="help-block">:message</p>'); ?>

                        </div>
                    </div>
                      
                    <div class="form-group <?php echo e($errors->has('start') ? 'has-error' : ''); ?>">
                    <div class="row">
                        <div class="col-3">    
                            <?php echo Form::label('start', 'Start', ['class' => 'col-3 control-label']); ?>         
                            <?php echo Form::input('time', 'start', null, ['class' => 'form-control']); ?>

                            <?php echo $errors->first('start', '<p class="help-block">:message</p>'); ?>

                        </div>
                        <div class="col-3"> 
                            <?php echo Form::label('end', 'End', ['class' => 'col-3 control-label']); ?>             
                            <?php echo Form::input('time', 'end', null, ['class' => 'form-control']); ?>

                            <?php echo $errors->first('end', '<p class="help-block">:message</p>'); ?>

                        </div>
                        <div class="col-3">
                            <?php echo Form::label('hour', 'Óraszám', ['class' => 'col-3 control-label']); ?> 
                            <?php echo Form::number('hour', null, ['class' => 'form-control']); ?>

                            <?php echo $errors->first('hour', '<p class="help-block">:message</p>'); ?>

                        </div>
                        <div class="col-3">
                                <?php echo Form::label('submit', '-', ['class' => 'col-3 control-label']); ?> 
                            <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Mentés', ['class' => 'btn btn-primary']); ?>

                        </div>

                    </div>
                    </div>              
                </form>
                <hr>
    </div>

    <div id="days" class="container tab-pane fade"><br> 
        <?php echo Form::model($data, [
            'method' => 'POST',
            'url' => ['/m/ad.wor.time/daystore'],
            'class' => 'form-horizontal',
            'files' => true
        ]); ?>

        <?php echo Form::hidden('datum', $data['datum'] ?? ''); ?>

        <div class="row">
                    <div class="col-4">            
                            <?php echo Form::label('daytype_id', 'Naptipus', ['class' => 'col-4 control-label']); ?>         
                            <?php echo Form::select('daytype_id', $data['daytype_id_list'], null, ['class' => 'form-control', 'required' => 'required']); ?>   
                            <?php echo $errors->first('daytype_id', '<p class="help-block">:message</p>'); ?>   
                    </div>  
                    <div class="col-8">
                            <?php echo Form::label('workernote', 'Megjegyzés', ['class' => 'col-8 control-label']); ?>

                            <?php echo Form::text('workernote', null, ['class' => 'form-control']); ?>

                            <?php echo $errors->first('workernote', '<p class="help-block">:message</p>'); ?>

                        </div>
                        <div class="col-3">
                            <?php echo Form::label('submit', '-', ['class' => 'col-3 control-label']); ?> 
                        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Mentés', ['class' => 'btn btn-primary']); ?>

                    </div>
                </div>
        <hr>
    </form>
    </div>
</div>         
             
  <?php /**PATH H:\laravel\workertime\resources\views/MOcalendar/form.blade.php ENDPATH**/ ?>