<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'Laravel')); ?> </title> 
 <?php
    $solver=$data['solver'];
    $workerid=$data['workerid'] ;
    $fulldata=$data['fulldata'];
    $times= $fulldata['times']['datekey'][$workerid] ?? [];
    $workerdays= $fulldata['workerdays']['datekey'][$workerid] ?? [];
  
  ?>

</head>
<body>

        <div  style="width:800px;">
                  
                            <div>munkanapok : <?php echo e($solver['sumWorkerdays']); ?>  </div>  
                            <?php $__currentLoopData = $solver['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dkey=> $wday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="">  
                                    <?php echo e($dkey); ?>:  <?php echo e(implode(',',$wday['days'])); ?> , összesen: <?php echo e($wday['sumdays']); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $solver['times']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkey=> $wtime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="">  
                                <?php echo e($tkey); ?>:  <?php echo e(implode(',',$wtime['hours'])); ?> , összesen: <?php echo e($wtime['sumhours']); ?>

                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <table border="1">
                <tr>
                    <th>Hétfő</th>
                    <th>Kedd</th>
                    <th>Szerda</th>
                    <th>Csütörtök</th>
                    <th>Péntek</th>
                    <th>Szombat</th> 
                    <th>Vasárnap</th>   
                </tr>
                               
                
                                    

             <?php $__currentLoopData = $fulldata['calendar']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekindex=> $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>    
                <?php $__currentLoopData = $week; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datum=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td>
                <div><?php echo e($item['day']); ?>  </div>
                    <?php if(isset($workerdays[$datum])): ?>
                        <?php $__currentLoopData = $workerdays[$datum]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workerday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
                    <div>        <?php echo e($workerday['daytype']['name']); ?> </div>     
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>  
                    <?php if(isset($times[$datum])): ?>
                        <?php $__currentLoopData = $times[$datum]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                     <div>    <?php echo e(substr($time['start'],0,5)); ?>- <?php echo e(substr($time['end'],0,5)); ?></div>         
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <?php endif; ?>       
        
                </td>     
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      
            </table>                         


     </div>
    
</body>
</html>
<?php /**PATH C:\ujworkertime\workeradmin\resources\views/pdfcell.blade.php ENDPATH**/ ?>