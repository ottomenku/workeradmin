

<?php $__env->startSection('content'); ?>
<div class="col-md-9">
    <div class="card">
        <div class="card-header"><?php echo e($viewpar['taskheader'] ?? $viewpar['app_name'] ?? $viewpar['route'] ?? 'index'); ?></div>
        <div class="card-body">
            <a href="<?php echo e(url($viewpar['route'].'/create')); ?>" dusk="new" class="btn btn-success btn-sm" title="Uj dokumentum kategória">
                <i class="fa fa-plus" aria-hidden="true"></i> Add New
            </a>

            <?php echo Form::open(['method' => 'GET', 'url' => url($viewpar['route']), 'class' => 'form-inline my-2 my-lg-0 float-right', 'role' => 'search']); ?>

            <div class="input-group">
                <input type="text" class="form-control" name="search" placeholder="Search..." value="<?php echo e(request('search')); ?>">
                <span class="input-group-append">
                    <button class="btn btn-secondary" type="submit">
                        <i class="fa fa-search"></i>
                    </button>
                </span>
            </div>
            <?php echo Form::close(); ?>

            <?php if($viewpar['tableform'] ?? false): ?>

            <?php $formroute= $viewpar['formroute'] ?? $viewpar['route']; ?>
            <?php echo Form::open(['method' => 'POST', 'url' => $formroute, 'class' => 'form-inline my-2 my-lg-0 float-right', 'role' => 'search']); ?>

            <br/> 
            <button class="btn btn-outline-<?php echo e($viewpar['gomb1,']['class'] ?? 'success'); ?> button-xs" value="<?php echo e($viewpar['gomb1']['val'] ?? 'pub'); ?>" type="submit"><?php echo e($viewpar['gomb1']['label'] ?? 'A kijelöltek engedélyezése'); ?></button>
            <button class="btn btn-outline-<?php echo e($viewpar['gomb2,']['val'] ?? 'danger'); ?>" value="<?php echo e($viewpar['gomb2,']['val'] ?? 'unpub'); ?>" type="submit"><?php echo e($viewpar['gomb2']['label'] ?? 'A kijelöltek tiltása'); ?></button>
            <div class="btn btn-outline-<?php echo e($viewpar['gomb2,']['val'] ?? 'danger'); ?>" ><input type="checkbox" id="checkAll" name="checkAll"><?php echo e($viewpar['gomb2']['label'] ?? 'összes kijelölése'); ?></div>
            <?php endif; ?>
            <br/>
            <div class="table-responsive">
                <table class="table table-borderless">
                    <thead>
                        <tr>
                            <?php $__currentLoopData = $viewpar['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($val[0] ?? $key); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if(!empty($viewpar['table_action'])): ?> <th>Actions</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $data['tabledata'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <?php $__currentLoopData = $viewpar['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php 
                            
                            if(isset($val[1])){
                            //TODO  az evalnál elegánsabb megoldást találni
                            eval('$value='.$val[1].';');  
                            }
                        else{$value=$item->$key;}
                            ?>
                        <th> <?php echo e($value); ?>  </th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($viewpar['table_action'])): ?>        
                            <td>

                        <?php if(isset($viewpar['table_action']['check'])): ?>  
                        <input class="checkbox" type="checkbox" name="id[]" value="<?php echo e($item->id); ?>">
                        <?php endif; ?>       
                        <?php if(isset($viewpar['table_action']['show'])): ?>  
                              <a href="<?php echo e(url($viewpar['route']).'/show/'. $item->id); ?>" title="View Category"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i></button></a>
                        <?php endif; ?>
                        <?php if(isset($viewpar['table_action']['edit'])): ?>       
                              <a href="<?php echo e(url($viewpar['route']).'/edit/'. $item->id); ?>" dusk="edit<?php echo e($item->id); ?>" title="Edit Category"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
                        <?php endif; ?>
                        <?php if(isset($viewpar['table_action']['destroy'])): ?>    
                        
                        <a href="<?php echo e(url($viewpar['route']).'/destroy/'. $item->id); ?>" dusk="destroy<?php echo e($item->id); ?>"  onclick="return confirm('Biztos hogy törölni akarja?')" title="Edit Category"><button class="btn btn-danger btn-sm"><i class="fa fa-trash-o" aria-hidden="true"></i></button></a>
                           
                        <?php endif; ?>        
                            </td>
                    <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination-wrapper"> </div>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>

<?php 
//dump($data);
//dump($data['tabledata'][0]['email']);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($viewpar['template'].'.'.$viewpar['frame'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mottoweb/workertime.mottoweb.hu/resources/views/baseTaskviews/index.blade.php ENDPATH**/ ?>