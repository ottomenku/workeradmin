
<div class="form-group ">                                                                 
  <label for="name" class="col-md-4 control-label"> Kelt:</label>
    <div class="col-md-6">    
        <input class="form-control" required="required" name="kelt" type="text" id="kelt" 
        value="<?php echo e($ceg->szekhely); ?>, <?php echo e(Carbon\Carbon::now()->toDateString()); ?> "> </div>     
</div> 

    
 <?php /**PATH C:\ujworkertime\workeradmin\resources\views/admin_crudgenerator/docs/adatkezeles_form.blade.php ENDPATH**/ ?>