<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <style> *{font-family: DejaVu Sans !important;} </style><!-- jók az ékezetes betúi --->
    <!-- include libraries(jQuery, bootstrap) -->
<link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<!-- include summernote css/js -->
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/lang/summernote-hu-HU.js"></script>
<style>
 .cp{cursor: pointer;}

</style>

<script>
  function kuldment(){
    $("#editform").prop("target", '_self');
    $('#editform').attr('action', "/m/ad.man.doc.doctemplate/formsave").submit();
}
$(document).ready(function() {
    $('#summernote').summernote({
        lang: 'hu-HU', // default: 'en-US'
      //  placeholder: 'Hello stand alone ui',
      fontNames: ['DejaVu Sans'],
        tabsize: 2,
        height: 400,
        buttons: {
           worker : workerDataInsert,
           ceg: cegDataInsert
        },  
        toolbar: [
            ['mybutton', ['worker']],
            ['mybutton2', ['ceg']],
       //   ['style', ['style']],
       ['style', ['style','bold', 'italic', 'underline', 'clear']],
       ['font', ['strikethrough', 'superscript', 'subscript']],
       ['fontsize', ['fontsize']],
          ['color', ['color']],
          ['para', ['ul', 'ol', 'paragraph']],
          ['table', ['table']],
       //   ['insert', ['link', 'picture', 'video']],
          ['view', ['fullscreen', 'codeview', 'help']]
        ]
      });
  });

</script>  
</head>
<body>
  <?php if(Session::has('flash_message')): ?>
  <div class="container">
      <div class="alert alert-success">
          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
          <?php echo e(Session::get('flash_message')); ?>

      </div>
  </div>
<?php endif; ?>
<?php if(Session::has('error_message')): ?>
<div class="container">
  <div class="alert alert-danger">
      <?php echo e(Session::get('error_message')); ?>

  </div>
</div>
<?php endif; ?>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
  <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php endif; ?>


<div style="margin:5%">   <center><h3>Dokumentum sablon generálás</h3> </center>

    <form id="editform" method="post" action="/m/ad.man.doc.doctemplate/preview" target="_blank">
      <button type="submit"  class="btn btn-primary" value="Submit"> Előnézet</button>  
      <button class="btn btn-primary" onclick="kuldment()" value="mentés">Mentés</button><br>

   <div class="row">
     <div class="col-md-6">
        <label class="control-label" for="note">Form neve</label>
        <input type="text" class="form-control"  name="name"> 
     </div>
      
     <div class="col-md-6">
        <label class="control-label" for="note">Kategória</label>
        <input type="text" class="form-control"  name="cat"> 
    </div>
    <div class="col-md-12">
      <label class="control-label" for="note">Megjegyzés</label>
      <input class="form-control" type="text" name="note"> <br>
    </div>
   </div>
      
     
      <textarea id="summernote" name="editordata"></textarea>
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    </form>
    <div style="display:none;">
     <ul class="workerattribute d-none" style="cursor: pointer;">
        <li data-value="<<['worker']['name']>>">Név</li>
        <li data-value="<<['worker']['user']['email']>>">Email</li>
    </ul>
    <ul class="cegattribute d-none" style="cursor: pointer;">
        <li data-value="<<['ceg']['cegname']>>">cégnév</li>
        <li data-value="<<['ceg']['adoszam']>>">Adószám</li>
    </ul>
    </div>

    <script>    
    var workerDataInsert = function (context) {
        var ui = $.summernote.ui;
      
        var event = ui.buttonGroup([
            ui.button({
                contents: 'Dolgozói adatok beszúrása <i class="fa fa-caret-down" aria-hidden="true"></i><span class="caret"></span>',
              //  tooltip: 'When you insert',
                data: {
                    toggle: 'dropdown'
                }
            }),
            ui.dropdown({
                className: 'drop-default summernote-list cp',
                contents: $('.workerattribute').html(),
                callback: function ($dropdown) {                    
                    $dropdown.find('li').each(function () {
                        $(this).click(function () {  
                      $('#summernote').summernote('editor.restoreRange');
                        $('#summernote').summernote('editor.focus');
                           $('#summernote').summernote('editor.insertText', $(this).data('value'));
                       // $('#summernote').summernote('editor.insertText', 'fghsghsghg');

                        });
                    });
                }
            })
        ]);        

        return event.render();    // return button as jquery object
      }
      var cegDataInsert = function (context) {
        var ui = $.summernote.ui;
      
        var event = ui.buttonGroup([
            ui.button({
                contents: 'Cég adatok beszúrása <i class="fa fa-caret-down" aria-hidden="true"></i><span class="caret"></span>',
              //  tooltip: 'When you insert',
                data: {
                    toggle: 'dropdown'
                }
            }),
            ui.dropdown({
                className: 'drop-default summernote-list cp',
                contents: $('.cegattribute').html(),
                callback: function ($dropdown) {                    
                    $dropdown.find('li').each(function () {
                        $(this).click(function () {  
                      $('#summernote').summernote('editor.restoreRange');
                        $('#summernote').summernote('editor.focus');
                           $('#summernote').summernote('editor.insertText', $(this).data('value'));
                       // $('#summernote').summernote('editor.insertText', 'fghsghsghg');

                        });
                    });
                }
            })
        ]);        

        return event.render();    // return button as jquery object
      }
      var preview = function (){
        
        var dataString =  $("#summernote").html();
        
        $.ajax({
          type: "POST",
          url: "/m/ad.man.doc.doctemplate/create",
          data: {
            "html": dataString,
            "_token": "<?php echo e(csrf_token()); ?>"
          },
          success: function(datas) {
            var w = window.open('about:blank');
            w.document.open();
            w.document.write(datas);
            w.document.close();
        },
        error: function(jqXHR) {
            showError("...");
        }
         /* success: function() {
            $('#form').html("<div id='message'></div>");
            $('#message').html("<h2>Message Submitted.</h2>")
            .append("<p>Thank you for contacting me, I will be in touch soon.</p>")
            .hide()
            .fadeIn(1500);
          }*/
        });
        return false;
        
        }
    </script>  
</body>
</html><?php /**PATH C:\ujworkertime\workeradmin\resources\views/doc_tmpl/general.blade.php ENDPATH**/ ?>