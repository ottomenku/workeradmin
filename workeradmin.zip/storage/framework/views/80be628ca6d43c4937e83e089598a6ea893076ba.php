<?php
    $daytype='base';
    if($dt['dayOfWeek']==6 || $dt['dayOfWeek']==0 ){$daytype='hollyday';}
    
    $timetype='base';
   /*onclick="datasendModal({'url':'http://localhost:8000/m/ad.work.time/create/{{$dt['datum']}}' }) ;
      <li class="flex-item btn btn-warning" href="/m/ad.wor.time/create/{{$dt['datum']}}" data-remote="false" data-toggle="modal" data-target="#myModal"
 
    */
?> 

  <li class="flex-item btn btn-warning" href="/m/ad.wor.time/create/" data-remote="false" data-toggle="modal" data-target="#myModal"
  style="<?php echo e($daystyle[$daytype]['li']); ?>">
        <div style="<?php echo e($daystyle[$daytype]['div']); ?>"><?php echo e($dt['day']); ?>

       <?php if(isset($dt['basedays'])): ?>
        <div style="<?php echo e($daystyle[$daytype]['div']); ?>"><?php echo e($dt['basedays']['daytype']['name']); ?>


        </div>
       <?php endif; ?> 
  <!-- idők-----------------------------------  --->      
    <?php if(isset($dt['times'])): ?>
        <?php $__currentLoopData = $dt['times']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
        <span style="<?php echo e($timestyle[$timetype]['span']); ?>" >   <?php echo e(str_limit($time['start'], 5,'' ).'-'.str_limit($time['end'], 5,'' )); ?>    
            </span> 
   <!--      <div style="display: flex;width:100%;justify-content:flex-end;<?php echo e($timestyle[$timetype]['div']); ?>">--->      
                <?php if($time['pub']==0): ?>         
                <span style="<?php echo e($timestyle[$timetype]['span']); ?>" >   <?php echo e(str_limit($time['start'], 5,'' ).'-'.str_limit($time['end'], 5,'' )); ?>    
                </span> 
                <?php endif; ?>
     <!--        </div>--->   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <?php endif; ?>        
        </li><?php /**PATH H:\laravel\workertime\resources\views/MOcalendar/days.blade.php ENDPATH**/ ?>