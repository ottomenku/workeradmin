<h4> <a href="/changeuser/aD15ll465ghAjfEbbulkkkkllllllhgzz/2"> Admin</a></h4>

<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <h3>  <?php echo e($item['cegdata']['cegnev']); ?> </h3>
   <h5>Manager: <a href="/changeuser/aD15ll465ghAjfEbbulkkkkllllllhgzz/<?php echo e($item['cegdata']['user_id']); ?>"> <?php echo e($item['cegdata']['user']['name']); ?> </a></h3>
<?php $__currentLoopData = $item['workers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5><?php echo e($worker['position'] ?? 'worker'); ?>: <a href="/changeuser/aD15ll465ghAjfEbbulkkkkllllllhgzz/<?php echo e($worker['user_id']); ?>"> <?php echo e($worker['workername']); ?> </a></h3>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\ujworkertime\workeradmin\resources\views/change.blade.php ENDPATH**/ ?>