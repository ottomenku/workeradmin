<?php
 function buttonGeneral($action,$viewpar,$item) {

    $baseActionKey=$viewpar['baseActionKey'] ?? 'mocontroller.mocontroller.baseAction';
    $baseAction=config($baseActionKey);
    $res='';

    if(is_array($action)){

        foreach ($action as $act) {
            $res.=  buttonGeneral($act,$viewpar,$item); 
        }  
    }else{
        $actual=$baseAction[$action];
        $task=$actual['task'] ?? $action;
        $res='<a ';
        if(isset($actual['action']) && $actual['action']=='href') 
        {$res.= 'href="'.url($viewpar['route']).'/'.$task.'/'. $item->id .'"';}
            $res.=' title="'.$actual['title'].'" class="'.$actual['class'].'"';
            if(!empty($actual['onclick'])) {$res.= 'onclick="'.$actual['onclick'].' " ';}
            if(!empty($actual['label'])) {$res.= $actual['label'];}
            $res.='>';
            if(!empty($actual['fa'])) {$res.='<i class="'.$actual['fa'].'" aria-hidden="true"></i>'; }                        
            $res.='</a>';                     
        $res.='</a>';
    }

    return $res;   
    }
   function actionbutton($action,$viewpar,$item) {
    if(is_array($action)){
    $publevel=  $viewpar['publevel'] ?? 5; //$publevel=  $viewpar['publevel'];
    switch ($action[0]) {
        case 'pub':
            $valuecol=$action[2] ?? 'pub';
            if($item->$valuecol>0){$action=$action[1];}else{$action='pub';}
            break;
        case 'pub_info':
            $valuecol=$action[2] ?? 'pub';
            if($item->$valuecol>0){  $action=$action[1];}else{$action='pub_info';}
            break;   
        case 'close':
            $valuecol=$action[2] ?? 'open';
            if($item->$valuecol>0){$action=$action[1];}else{$action='close';}
                    break;
        case 'close_info':
            $valuecol=$action[2] ?? 'open';
            if($item->$valuecol>0){ $action=$action[1]; }else{$action='open_info';}
                break;
        default:
            # code...
        break;
    }      
    }
 return buttonGeneral($action,$viewpar,$item);
} 
 ?><?php /**PATH D:\laravel\workertime\resources\views/includes/table/actionFunc.blade.php ENDPATH**/ ?>