<div class="table-responsive">
    <table class="table table-borderless">
        <thead>
            <tr>
                <?php $__currentLoopData = $viewpar['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th><?php echo e($val[0] ?? $key); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty($viewpar['table_action'])): ?> <th>Actions</th><?php endif; ?>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $data['tabledata'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <?php $__currentLoopData = $viewpar['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                
               // if(isset($val[1])){
                if(substr($key,0,4)=='eval'){   
                //TODO  az evalnál elegánsabb megoldást találni
                eval('$value='.$val[1].';');  
                }     
                elseif (substr($key,0,4)=='join'){ //substr() azért kell hogy lehessen indexelni
                   $joinfunc=$val[1];
                    $joinvar=$val[2];
                    $value=$item->$joinfunc->$joinvar;        
                }
                elseif (substr($key,0,5)=='files'){
                    $joinfunc=$val[1];
                  //  if(is_array($item->$joinfunc)){
                        $value=''; 
                        foreach($item->$joinfunc as $file){                                
                            $value.='<a class="btn btn-primary btn-sm" href="'.url($viewpar['route']).'//download/'.$file->id.'">'.$file->name.' </a>&nbsp;';
                     //   }                                               
                    }
                }
                else{$value=$item->$key;}
                ?>
            <td> <?php echo $value; ?>  </td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if(!empty($viewpar['table_action'])): ?>        
                <td>

            <?php if(isset($viewpar['table_action']['check'])): ?>  
            <input class="checkbox" type="checkbox" name="id[]" value="<?php echo e($item->id); ?>">
            <?php endif; ?>       
            <?php if(isset($viewpar['table_action']['show'])): ?>  
                  <a href="<?php echo e(url($viewpar['route']).'/show/'. $item->id); ?>" title="Megnéz"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i></button></a>
            <?php endif; ?>
            <?php if(isset($viewpar['table_action']['edit'])): ?>       
                  <a href="<?php echo e(url($viewpar['route']).'/edit/'. $item->id); ?>" dusk="edit<?php echo e($item->id); ?>" title="Szerkesztés"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button></a>
            <?php endif; ?>
            <?php if(isset($viewpar['table_action']['destroy'])): ?>    
            
            <a href="<?php echo e(url($viewpar['route']).'/destroy/'. $item->id); ?>" dusk="destroy<?php echo e($item->id); ?>"  onclick="return confirm('Biztos hogy törölni akarja?')" title="törlés"><button class="btn btn-danger btn-sm"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
            </a>
               
            <?php endif; ?> 
            <?php if(isset($viewpar['table_action']['pub'])): ?>    
                <?php if($item->id<5): ?> 
                <a href="<?php echo e(url($viewpar['route']).'/pub/'. $item->id); ?>" dusk="pub<?php echo e($item->id); ?>"  title="Jóváhagyás"><button class="btn btn-danger btn-sm"><i class="fa fa-circle" aria-hidden="true"></i></button></a>
                <?php else: ?>
                <a href="<?php echo e(url($viewpar['route']).'/unpub/'. $item->id); ?>" dusk="unpub<?php echo e($item->id); ?>"  title="tiltás"><button class="btn btn-success btn-sm"><i class="fa fa-check-circle" aria-hidden="true"></i></button></a>
                <?php endif; ?>
            <?php endif; ?> 
            
                </td>
        <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table><?php /**PATH D:\laravel\workertime\resources\views/includes/table/table_old.blade.php ENDPATH**/ ?>