<?php $__env->startSection('content'); ?>

<style>
    .table th, .table td {
        padding: 0.25rem;
      }

      [class*="col-"],  /* Elements whose class attribute begins with "col-" */
      [class^="col-"] { /* Elements whose class attribute contains the substring "col-" */
        padding-left: 5px;
        padding-right: 0;
      }

</style>
<div  class="col-md-9">
    <div class="card">
        <div class="card-header"><?php echo e($viewpar['taskheader'] ?? $viewpar['app_name'] ?? $viewpar['route'] ?? 'index'); ?>

        </div>
        <div class="card-body"> 
                <br>
  <!-- vue applikáció------------------------------------------------------>                     
    <div id="app"> 
      <!-- modal button----------------------------->
      <div  class="float-right"><i style="color:blue;font-size:2rem;"
              v-on:click="showModalInfo()"class="fa fa-info-circle"></i> 
      </div>
      
      
      <!-- modal info------------------------------->
        <modal v-if="showInfo" @close="showInfo = false">    
        <div slot="body">  
          <?php echo $viewpar['info'] ?? 'Ehhez a feladathoz nincs információ, ha problémája van kérjük hívja az ügyfélszolgálatot!'; ?>

        </div>
        </modal>   
      
  <!-- modal-------->
          <modal v-if="showModal" @close="showModal = false">
              <div slot="body">            
  <?php echo $__env->make('mocalendarVue.inc.showstored', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
              </div>
          </modal>

   <!--  panel---------------------------------------------------------------------->                 
   <div class="container">
   <ul class="nav nav-tabs nav-justified">
    <li class="nav-item">
        <a class="nav-link" @click.prevent="setActive('home')" :class="{ active: isActive('home') }" href="#home">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" @click.prevent="setActive('stored')" :class="{ active: isActive('stored') }" href="#stored">Havi zárások</a>
      </li> 
 
  </ul>        
  <div class="tab-content py-3" id="myTabContent">
    <div class="tab-pane fade" :class="{ 'active show': isActive('home') }" id="home">Home content </div>

    <!-- stored ---------------------------------------------------------------------->        
    <div class="tab-pane fade" :class="{ 'active show': isActive('stored') }" id="stored">
        <div class="table-responsive">
  <?php echo $__env->make('mocalendarVue.inc.stored_table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                             

    </div>
        
  </div> 
   </div>     
<!-- funkció gombok -------------------------------------------------->
<?php echo $__env->make('mocalendarVue.inc.ev_ho',['refreshTask' => "freshdata"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- calendar ---------------------------------------------------------------->
<?php echo $__env->make('mocalendarVue.inc.calendar_worker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                             
        </div>
      </div> 
    </div>
</div>

<?php echo $__env->make('mocalendarVue.inc.modal_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make($viewpar['template'].'.backendVue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ujworkertime\workeradmin\resources\views/mocalendarVue/calendarWorker.blade.php ENDPATH**/ ?>