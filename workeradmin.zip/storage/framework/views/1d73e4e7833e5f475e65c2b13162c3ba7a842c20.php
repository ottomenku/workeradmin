<?php
  $tableFuncInc= $viewpar['tableFuncInc'] ?? 'includes.table.simpleActionFunc';
 // $actions=$viewpar['table']['actions'][1] ?? [];
 //@include($tableFuncInc) 
 //include('..\resources\views\includes\table\actionFunc.php') ;
?> 
<?php echo $__env->make($tableFuncInc, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>           
<div class="table-responsive">
    <table class="table table-borderless">
<!-- fejléc -->                        
        <thead>
            <tr>
                <?php $__currentLoopData = $viewpar['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     
                    <?php if(isset($viewpar['table_action']['check'])): ?>  
                        <th>  
                    <!-- oszzes kijelölése ha kell-->   
                    <input class="checkbox" type="checkbox" name="all" value="true">
                        </th>  
                    <?php else: ?> 
     
                    <th>
                    <?php echo e($val[0] ?? $key); ?>

                    </th>
                    <?php endif; ?> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
<!-- sorok -->                 
        <tbody>
        <?php $__currentLoopData = $data['tabledata'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <?php $__currentLoopData = $viewpar['table']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
                <td> 
                <?php if(substr($key,0,6)=='action'): ?>
               
                    <?php $__currentLoopData = $val[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                       
                   <?php echo actionbutton($action,$viewpar,$item); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                   
                <?php else: ?>
<?php  //----------------------------------------------------------------------------------
              
                   if(substr($key,0,4)=='eval'){   
                    //TODO  az evalnál elegánsabb megoldást találni
                    eval('$value='.$val[1].';');  
                    }     
                    elseif (substr($key,0,4)=='join'){ //substr() azért kell hogy lehessen indexelni
                    $joinfunc=$val[1];
                        $joinvar=$val[2];
                        $value=str_limit($item->$joinfunc->$joinvar, 20, '...');        
                    }
                    elseif (substr($key,0,5)=='files'){
                        $joinfunc=$val[1];
                            $value=''; 
                            foreach($item->$joinfunc as $file){                                
                                $value.='<a class="btn btn-primary btn-sm" href="'.url($viewpar['route']).'/download/'.$file->id.'">'.str_limit($file->name, 20, '...').' </a>&nbsp;';                                              
                        }
                    }
                    else{$value=str_limit($item->$key, 20, '...');}
    //-----------------------------------------------------------------------------------------                
?>

                <?php echo $value; ?> 
                </td>
            <?php endif; ?>
                
      
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
</table><?php /**PATH /home/www/pnet1408_drtjosep/public_html/workertime_dev/resources/views/includes/table/table.blade.php ENDPATH**/ ?>