<?php

namespace Tests\Features;
use Route;
use Tests\TestCase;
use \Ottomenku\MoController\Tests\Features\MoControllerTestHandler;
class urlTest extends TestCase
{
//handlerrel start: Tests\Features\MoControllerTestHandler-------------------;
    public function testsetUrlParam()
    {
        Route::group(['prefix' => 'admin'], function () {
            Route::any('test6/{func}/{id}/{id1}/{id2}', '\Ottomenku\MoController\Tests\TestHandler@runFuncAndRes')
                ->name('dashboard');
        });
        Route::any('test6/{func}/{id}/{id1}/{id2}', '\Ottomenku\MoController\Tests\TestHandler@runFuncAndRes')
        ->name('dashboard');
       
        $response = $this->call('GET', 'admin/test6/setUrlParam/id/id1/id2');
        //$response->assertSee('kkk');
        $response
            ->assertStatus(200)
            ->assertJson([
                'ACT' => ['prefix' => 'admin', 'routname' => 'dashboard', 'task' => 'runFuncAndRes',
                    'urlparams' => ['id' => 'id', 'id1' => 'id1', 'id2' => 'id2'],
                ],
            ]);

           Route::any('test7/{func}/{id}/{id1}/{id2}', '\Ottomenku\MoController\Tests\TestHandler@runFuncAndRes');
          
            $response = $this->call('GET', 'test7/setUrlParam/id/id1/id2');
            //$response->assertSee('kkk');
            $response
                ->assertStatus(200)
                ->assertJson([
                    'ACT' => ['prefix' => false, 'routname' => false, 'task' => 'runFuncAndRes',
                        'urlparams' => ['id' => 'id', 'id1' => 'id1', 'id2' => 'id2'],
                    ],
                ]);


    }

    public function testsetUrlParamWithTask()
    {

        Route::group(['prefix' => 'admin'], function () {
            Route::any('test1/{func}/{task}/{id}/{id1}/{id2}', '\Ottomenku\MoController\Tests\TestHandler@runFuncAndResWithTask')
                ->name('dashboard');
        });
        $response = $this->call('GET', 'admin/test1/setUrlParamWithTask/task/id/id1/id2');
        $response
            ->assertStatus(200)
            ->assertJson([
                'ACT' => ['prefix' => 'admin', 'routname' => 'dashboard', 'task' => 'task',
                    'urlparams' => ['id' => 'id', 'id1' => 'id1', 'id2' => 'id2'],
                ],
            ]);
    }
  //handlerrel end------------------------------------------------------------------------
}
