<?php

namespace Tests\Unit;

//use Tests\DuskTestCase;
use Ottomenku\MoController\MoController;
//use PHPUnit\Framework\TestCase as BaseTestCase;
//use Illuminate\Http\Request;
//use Illuminate\Routing\Route as Route2;
//use Illuminate\Support\Facades\View;
//use Illuminate\Support\Facades\Route as RouteF;
use Route;
use Tests\TestCase;

//class MoControllerTest extends TestCase
class MoControllermm
{
public function testsetOB()
{
     $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandler');

    $ControllerM->ACT['obClass']=[
      'TestClassToOB2'=>'Ottomenku\MoController\Tests\TestClassToOB2',
      'TestClassToOB1'=>'Ottomenku\MoController\Tests\TestClassToOB1'
  ];
  $ControllerM->setOB();
   $this->assertEquals($ControllerM->OB['TestClassToOB1']->testclasPar1,1);
   $this->assertEquals($ControllerM->OB['TestClassToOB2']->testclasPar2,1);
}
public function func1($a,$b='')
{
    return $a;
}

}

