<?php

namespace Tests\Unit;

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
//use Tests\DuskTestCase;
use Ottomenku\MoController\MoController;
//use PHPUnit\Framework\TestCase as BaseTestCase;
//use Illuminate\Http\Request;
//use Illuminate\Routing\Route as Route2;
//use Illuminate\Support\Facades\View;
//use Illuminate\Support\Facades\Route as RouteF;
use Route;
use Tests\TestCase;

//class ORMTest extends TestCase
class ORMmm
{ 
   
public function memoryDB()

{
   config(['database.connections.sqlite_testing' => [       
        'driver'   => 'sqlite',
        'database' => ':memory:',
        'prefix'   => '',    
    ]]);
    config(['database.default' => 'sqlite_testing']);
}
public function testMemoryDB()
{
 $this->memoryDB();   
   Schema::create('users2', function (Blueprint $table) {
        $table->increments('id');
        $table->string('testname');
        $table->integer('votes');
    });


    \DB::table('users2')->insert(
        ['testname' => 'john', 'votes' => 1]
    );
  // $user = \DB::table('users2')->where('testname', 'john')->first();
   $user = \DB::table('users2')->where([
    ['testname', '=', 'john'],
    ['votes', '=', '1'],//['votes', 'like', '1'],
])->first();
  //  $ControllerM = \App::make('Ottomenku\MoController\Tests\MoControllerTestHandler');

   $this->assertEquals($user->testname,'john');
  
} 
/* 
public function testModelGen()
{
   // Storage::put('app/mytextdocument.php','John Doe');
  $gg=new \Ottomenku\MoInstaller\ModelGenerator('jjj'); 
   $res=$gg->buildClass('post');
    $fp = fopen('app/post.php', 'w');
    fwrite($fp, $res);
    fclose($fp); 
    //parent::setUp(); 
   // \App::make('artisan')->call("php artisan crud:model Post --fillable=['title', 'body']");
   \Artisan::call("crud:model Post");
    $this->assertEquals('john1','john');
}
*/

}

