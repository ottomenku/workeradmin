<?php
namespace Tests\Unit;

use Ottomenku\MoController\MoController;
use Tests\TestCase;

//class FuncrunTest extends TestCase
class Funcrun
{
    /**
     * A moController alap funcRun()-ja csak a funkcion neveket kapja meg egy tömbben. 
     * $this->ben hívja meg paraméterek és visszatérési érték nélkül
     */
    public function testBasefuncRunbase($funcs = [])
    {
        $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandler');
        $ControllerM->funcRun(['testFunc1']);
        $this->assertEquals($ControllerM->MT, ['testfunctions' => ['testFunc1']]);
        $ControllerM->funcRun('testFunc2,testFunc3');
        $this->assertEquals($ControllerM->MT, ['testfunctions' => ['testFunc1', 'testFunc2', 'testFunc3']]);
        $ControllerM->funcRun();
        $this->assertEquals($ControllerM->MT, ['testfunctions' => ['testFunc1', 'testFunc2', 'testFunc3']]);
        $ControllerM->funcRun(null);
        $this->assertEquals($ControllerM->MT, ['testfunctions' => ['testFunc1', 'testFunc2', 'testFunc3']]);
        $ControllerM->funcRun('');
        $this->assertEquals($ControllerM->MT, ['testfunctions' => ['testFunc1', 'testFunc2', 'testFunc3']]);
        $ControllerM->funcRun(false);
        $this->assertEquals($ControllerM->MT, ['testfunctions' => ['testFunc1', 'testFunc2', 'testFunc3']]);      
    }
   /**
    * teljes funkcionalitású funcRun, paraméterekkel osztállyal, visszatérési értékkel
    * nem associatív tömbben tárolja a függvényhívás adatait, áttekinthetőbb de kötöttebb
    *  * exaample: 'obkey.funktionName'=>[['string','user.id_DATA'],'data.res_ACT'],
    * obkey: a $this->OB-ban tárolt objektum kulcsa. Nem az osztály vagy az objektum neve!!!!!
    *  data.res_ACT: (string) ez adja meg hova írja a visszatérési értéket
    * az első tag ('_'- jellel elválasztva) az adat elérési útja. A második tag a property neve 
    */
    public function testfuncRun($funcs = [])
    {
        $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandlerToFuncrunFull');
        $ControllerM->OB['ClassOB1'] = new \Ottomenku\MoController\Tests\ClassOB11();
        $ControllerM->OB['ClassOB2'] = new \Ottomenku\MoController\Tests\ClassOB21();
        //sima ob funkció
        $ControllerM->funcRun([
            'ClassOB1.ob1Func'=>[['get.id_ACT', 'sima string'],'user.name_DATA']]
        );

        //sima void this funkció 
        $ControllerM->funcRun([
            'voidFunc'=>[['get.id_ACT', 'sima string3']]]
        );
        $this->assertEquals($ControllerM->MT['testfunctions']['voidFunc'], 'getidsima string3');

        //this funkció  betehetjük a thist az OB-ba de igazából ha nem találja az adott kulcsot a z obban akkor is a this t futtatja
        $ControllerM->funcRun([
            'this.testFunc1'=>[['get.id_ACT', 'sima string'],'user.name3_DATA']]
    
        );
        $this->assertEquals($ControllerM->DATA['user']['name3'], 'this-getid-sima string');
        // ha nem adunk meg ob-ot akkor is a thist futtatja
        $ControllerM->funcRun([
            'testFunc1'=>[['get.id_ACT', 'sima string'],'user.name3_DATA']]
        );
        $this->assertEquals($ControllerM->DATA['user']['name3'], 'this-getid-sima string');
    }
   /**
    * A Ottomenku\MoController\Trt\Funcrun\funcrunFullwithAssocPar traitben található funcRun
    *teljes funkcionalitású funcRun, paraméterekkel osztállyal, visszatérési értékkel Associatív tömbben
    * példa: ['func' => 'ob1Func', 'par' => ['get.id_ACT', 'sima string'], 'to' => 'user.name_DATA', 'ob' => 'ClassOB1']]
    * ob: a $this->OB-ban tárolt objektum kulcsa. Nem az osztály vagy az objektum neve!!!!!
    * to: (string) hova írja a visszatérési értéket
    * az első tag ('_'- jellel elválasztva) az adat elérési útja. A második tag a property neve 
    */
    public function testfuncRunAssoc($funcs = [])
    {
        $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandlerToFuncrunAssoc');
        $ControllerM->OB['ClassOB1'] = new \Ottomenku\MoController\Tests\ClassOB1();
        $ControllerM->OB['ClassOB2'] = new \Ottomenku\MoController\Tests\ClassOB2();
        //sima ob funkció
        $ControllerM->funcRun([
            ['func' => 'ob1Func', 'par' => ['get.id_ACT', 'sima string'], 'to' => 'user.name_DATA', 'ob' => 'ClassOB1']]
        );
        $this->assertEquals($ControllerM->DATA['user']['name'], 'ob1-getid-sima string');
        // ob funkció saját egy paraméterrel
        $ControllerM->funcRun([
            ['func' => 'resFunc1', 'par' => ['get.id_ACT'], 'to' => 'user.name2_DATA', 'ob' => 'ClassOB2']]
        );
        $this->assertEquals($ControllerM->DATA['user']['name2'], 'ob2-1-getid');
        //this funkció  betehetjük a thist az OB-ba de igazából ha nem találja az adott kulcsot a z obban akkor is a this t futtatja
        $ControllerM->funcRun([
            ['func' => 'testFunc1', 'par' => ['get.id_ACT', 'sima string'], 'to' => 'user.name3_DATA', 'ob' => 'this']]
        );
        $this->assertEquals($ControllerM->DATA['user']['name3'], 'this-getid-sima string');
        // ha nem adunk meg ob-ot akkor is a thist futtatja
        $ControllerM->funcRun([
            ['func' => 'testFunc1', 'par' => ['get.id_ACT', 'sima string'], 'to' => 'user.name3_DATA']]
        );
        $this->assertEquals($ControllerM->DATA['user']['name3'], 'this-getid-sima string');
            //sima void this funkció 
            $ControllerM->funcRun([
                ['func' => 'voidFunc', 'par' => ['get.id_ACT', 'sima string3']]]
            );
            $this->assertEquals($ControllerM->MT['testfunctions']['voidFunc'], 'getidsima string3');
    
    }

}
