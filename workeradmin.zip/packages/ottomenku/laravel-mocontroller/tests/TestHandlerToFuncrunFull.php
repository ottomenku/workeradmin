<?php

namespace Ottomenku\MoController\Tests;
use Ottomenku\MoController\Tests\TestHandler;


class ClassOB11 
{ 
    public function ob1Func($a,$b)
    {
        return 'ob1-'.$a.'-'.$b;
    }
}
    class ClassOB21 
{
    public $testclasPar=1;
    public function voidFunc1($a)
    {
       $this->testclasPar=$a;
    }
    public function resFunc1($a)
    {
        return 'ob2-'.$this->testclasPar.'-'.$a;
    }
}   
 class TestHandlerToFuncrunFull extends TestHandler
{
    use \Ottomenku\MoController\Trt\Funcrun\FuncrunFull;
    public  $ACT=['get'=>['id'=>'getid']];
    public  $DATA=[];
    public  $OB=[];
}

