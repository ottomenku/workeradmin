<?php

namespace Tests\Unit;

//use Tests\DuskTestCase;
use Ottomenku\MoController\MoController;
use Ottomenku\MoController\MocontrollerServiceProvider;
//use PHPUnit\Framework\TestCase as BaseTestCase;
//use Illuminate\Http\Request;
//use Illuminate\Routing\Route as Route2;
//use Illuminate\Support\Facades\View;
//use Illuminate\Support\Facades\Route as RouteF;
use Route;
use Tests\TestCase;

class SetPropTest extends TestCase
{ 
    public function testTrue()
    {$this->assertTrue(true);}
   /* public $testBaseArr= [
        'base'=>[
            'basedat'=>[ 'key1'=>'ok','key2'=>'ok'],   
            'key'=>'ok',
            'datForDel'=>'ok'
        ],
        'task1'=>[ 
            'basedat'=>[ 'key3'=>'ok'],  
            'key'=>'ok',
            'functions'=>[['name'=>'testFunc1','par'=>[]]],
            'delFromParrent'=>'datForDel,key.cc', //csak string lehet vesszővel elválasztva nem érdemes tömbel variálni
        ],
        'task2'=>[['arr']],
        
    ];
    public $testSetArr= [
        'base'=>[
          'basedat'=>[ 'key4'=>'ok'],   
            'key'=>'ok2',
            'delFromParrent'=>'basedat',
        ],
        'task1'=>[ 
            'basedat'=>[ 'key5'=>'ok',]     
        ],
    ];
    public $testSetArr2= [
        'base'=>[
            'basedat'=>[ 'key4'=>'base4'],   
              'key'=>'ok2'
          ],
          'task1'=>[  
            'key'=>'ok3',
            'functions'=>['ujtestFunc1'],
            'delFromParrent'=>'functions',
          ],
        
    ];
    public function testget()
    { 
    $ControllerM = \App::make('Ottomenku\MoController\MoControllerNoauto');
    $ControllerM->ACT=$this->testSetArr2;
 $this->assertEquals($ControllerM->get('ACT.base.basedat.key4'),'base4');
}
    
  //  public function testTrue() {$this->assertTrue(true);}

 public function testsetRoutname()
  {

      Route::group(['prefix' => 'admin'], function () {
        Route::resource('user/', '\Ottomenku\MoController\MoController',['as' => 'adminGroup.user']);
        Route::get('worker/', '\Ottomenku\MoController\MoController@testbase')->name('adminGroup.worker.task');  
    });

    $response = $this->call('GET', 'admin/user');
    $ControllerM = \App::make('Ottomenku\MoController\MoControllerNoauto');
    $fullpathS= $ControllerM->setRoutname(); 
    $this->assertEquals($ControllerM->ACT['routname'],'adminGroup.user.index');

    $response = $this->call('GET', 'admin/worker');
    $ControllerM = \App::make('Ottomenku\MoController\MoControllerNoauto');
    $fullpathS= $ControllerM->setRoutname(); 
    
    $this->assertEquals($ControllerM->ACT['routname'],'adminGroup.worker.task');
    $this->assertEquals($fullpathS,['mocontrollerGroup','adminGroup','worker','task']);

    $fullpathS= $ControllerM->setTask($fullpathS); 
    $this->assertEquals($fullpathS,['mocontrollerGroup','adminGroup','worker']);
    $this->assertEquals($ControllerM->ACT['task'],'task');
}



public function testsetConfigFromRoutname()
{
    config(['mocontrollerGroup.groupconf'=>$this->testBaseArr]);
    Route::group(['prefix' => 'admin'], function () {
        Route::resource('user/', '\Ottomenku\MoController\MoController',['as' => 'adminGroup.user']);
        Route::get('worker/', '\Ottomenku\MoController\MoController@setConfigFromRoutname')->name('adminGroup.worker.task1');  
    });

    $response = $this->call('GET', 'admin/worker');
    $ControllerM = \App::make('Ottomenku\MoController\MoControllerNoauto');
    $ControllerM->setConfigFromRoutname();
   // $ControllerM->confToACT('mocontrollerGroup','task1');
    $this->assertEquals($ControllerM->ACT,[ 
    'routname' => 'adminGroup.worker.task1'
    ,'task' => 'task1'
    ,'basedat' =>[ 'key1'=>'ok','key2'=>'ok','key3'=>'ok']
    ,'key' => 'ok'
    ,'functions' =>[['name'=>'testFunc1','par'=>[]]]
    ,'delFromParrent' => 'datForDel,key.cc']);

    config(['mocontrollerGroup.adminGroup.groupconf'=>$this->testSetArr]);
    $response = $this->call('GET', 'admin/worker');
    $ControllerM->setConfigFromRoutname();
    $this->assertEquals($ControllerM->ACT,[ 
    'routname' => 'adminGroup.worker.task1'
    ,'task' => 'task1'
    ,'basedat' =>['key4'=>'ok','key5'=>'ok'],'key'=>'ok2'
    ,'key' => 'ok2'
    ,'functions' =>[['name'=>'testFunc1','par'=>[]]]
    , 'delFromParrent'=>'basedat']); 


  config(['mocontrollerGroup.adminGroup.worker'=>$this->testSetArr2]);
    $response = $this->call('GET', 'admin/worker');
    $ControllerM->setConfigFromRoutname();
    $this->assertEquals($ControllerM->ACT,[ 
    'routname' => 'adminGroup.worker.task1'
    ,'task' => 'task1'
    ,'basedat' =>['key4'=>'base4','key5'=>'ok'],'key'=>'ok2'
    ,'key' => 'ok3'
    ,'functions' =>['ujtestFunc1']
    , 'delFromParrent'=>'functions']); 
   
}


/*
public function testgroupConfToMT()
{
    $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandler');
    $ControllerM->MT = $this->testBaseArr;
    $ControllerM->configDir = 'testdir';
    //ha nincs group prefix
    $ControllerM->ACT['prefix'] = false;
    $ControllerM->groupConfToMT();
    $this->assertEquals($ControllerM->MT, $this->testBaseArr);
    $this->assertEquals($ControllerM->configDir, 'testdir');
    // ha nincs group config------------------
    $ControllerM->ACT['prefix'] = 'groupdir';
    $ControllerM->groupConfToMT();
    $this->assertEquals($ControllerM->MT, $this->testBaseArr);
    $this->assertEquals($ControllerM->configDir, 'testdir.groupdir');
    //  ha minden ok
    $ControllerM->configDir = 'testdir';
    config(['testdir.groupdir.base' => $this->testSetArr]);
    $ControllerM->groupConfToMT();
    $this->assertEquals($ControllerM->MT, $this->testMergedArr);
    $this->assertEquals($ControllerM->configDir, 'testdir.groupdir');
}
public function testroutnameConfToMT()
{
    $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandler');
    $ControllerM->configDir='testdir';
    $ControllerM->MT=$this->testBaseArr;
    //ha nincs routname 
    $ControllerM->ACT['routname']=false;  
    $ControllerM->routnameConfToMT(); 
    $this->assertEquals($ControllerM->MT,$this->testBaseArr);
    // ha nincs routname config
    $ControllerM->ACT['routname']='rout1';
    $ControllerM->MT=$this->testBaseArr;
    $ControllerM->routnameConfToMT();  
    $this->assertEquals($ControllerM->MT,$this->testBaseArr); 
    // minden ok
    config(['testdir.rout1'=>$this->testSetArr]);
    $ControllerM->routnameConfToMT(); 
    $this->assertEquals($ControllerM->MT,$this->testMergedArr);
}

public function testPARToMT()
{
    $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandler');
    $ControllerM->MT=$this->testBaseArr;
    $ControllerM->PAR=$this->testSetArr;
    $ControllerM->PARToMT(); 
    $this->assertEquals($ControllerM->MT,$this->testMergedArr);
}


public function testsetACT()
{
   $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandler');
     $task=$ControllerM->ACT['task'] ?? 'task1';
    $ControllerM->ACT['task'] = 'task1';
    $ControllerM->MT=$this->testSetArr;
    $ControllerM->setACT(); 
    $this->assertEquals($ControllerM->ACT,[ 
    'task'=>'task1',    
    'basedat'=>[ 'key3'=>'ok','key2'=>'ok2',],   
    'key'=>'ok2',
    'key2'=>'ok',
    'functions'=>[1=>['name2'=>'testFunc','par'=>[]],2=>['name'=>'testFunc','par'=>[]]],   ]);
  
   // $this->assertEquals(1,1);
}
 
public function testmergeParWithProp(){
    $ControllerM = \App::make('Ottomenku\MoController\Tests\TestHandler');
    $ControllerM->MT=$this->testBaseArr;
    //ha nincs testSetArr
    $ControllerM->mergeParWithProp('MT'); 
    $this->assertEquals($ControllerM->MT,$this->testBaseArr);
    //ha null testSetArr
    $ControllerM->mergeParWithProp('MT', null); 
    $this->assertEquals($ControllerM->MT,$this->testBaseArr);
    //ha false testSetArr
    $ControllerM->mergeParWithProp('MT', false); 
    $this->assertEquals($ControllerM->MT,$this->testBaseArr);
    //ha minden ok
    $ControllerM->mergeParWithProp('MT',$this->testSetArr ); 
    $this->assertEquals($ControllerM->MT,$this->testMergedArr);
    }


  public function testremoveFromProp()
  {
    //config(['mocontroller1'=>['motest'=>'ok']]);
    //  $ControllerM = \App::make('\Ottomenku\MoController\Tests\MoControllerTestHandler');
    $ControllerM = \App::make('Ottomenku\MoController\MoControllerNoauto');
    $ControllerM->ACT=['mocontroller1'=>['motest'=>'ok','motest2'=>'ok','motest3'=>'ok','motest4'=>'ok','motest5'=>'ok','motest6'=>'ok']];
    //eltávolítás stringel single 
    $ControllerM->removeFromProp('ACT','mocontroller1.motest'); ;
    $this->assertEquals($ControllerM->ACT,['mocontroller1'=>['motest2'=>'ok','motest3'=>'ok','motest4'=>'ok','motest5'=>'ok','motest6'=>'ok']]);
    //eltávolítás stringel multiple
    $ControllerM->removeFromProp('ACT','mocontroller1.motest2,mocontroller1.motest3'); ;
    $this->assertEquals($ControllerM->ACT,['mocontroller1'=>['motest4'=>'ok','motest5'=>'ok','motest6'=>'ok']]);
    //eltávolítás tömbbel
    $ControllerM->removeFromProp('ACT',['mocontroller1.motest4','mocontroller1.motest5']); ;
    $this->assertEquals($ControllerM->ACT,['mocontroller1'=>['motest6'=>'ok']]);
    //nem létező kulcs
    $ControllerM->removeFromProp('ACT',['mmm.kkk']); ;
    $this->assertEquals($ControllerM->ACT,['mocontroller1'=>['motest6'=>'ok']]);
    //nincs dotkey
    $ControllerM->removeFromProp('ACT'); 
    $this->assertEquals($ControllerM->ACT,['mocontroller1'=>['motest6'=>'ok']]);
    // dotkey null
    $ControllerM->removeFromProp('ACT',null); 
    $this->assertEquals($ControllerM->ACT,['mocontroller1'=>['motest6'=>'ok']]);
     // dotkey false
    $ControllerM->removeFromProp('ACT',false); 
    $this->assertEquals($ControllerM->ACT,['mocontroller1'=>['motest6'=>'ok']]);
     // dotkey ''
    $ControllerM->removeFromProp('ACT',''); 
    $this->assertEquals($ControllerM->ACT,['mocontroller1'=>['motest6'=>'ok']]);
}
*/
}

