<?php

namespace Tests\Unit;

//use Tests\DuskTestCase;
use Ottomenku\MoController\MoController;
//use PHPUnit\Framework\TestCase as BaseTestCase;
//use Illuminate\Http\Request;
//use Illuminate\Routing\Route as Route2;
//use Illuminate\Support\Facades\View;
//use Illuminate\Support\Facades\Route as RouteF;
use Route;
use Tests\TestCase;
//H:\laravel\laravel_with_mocontroller\packages\ottomenku\laravel-mocontroller\tests\unit\UrlParamTest.php
class UrlParamTest extends TestCase
{ 
    public function testTrue()
    {$this->assertTrue(true);}
    public function testreplaceVal()
    {
        //config(['mocontrollerGroup.groupconf'=>$this->testBaseArr]);
    
       $response = $this->call('GET', 'm/ad.man.worker');
    
        $ControllerM = \App::make('App\Http\Controllers\BaseWithRouteController');
        $str='ggg/{DATA.id}/{ACT.baseroute}/crrr';
        $ControllerM->DATA['id']=11;
        $ControllerM->ACT['baseroute']='admin/man.user';
        //$arr=['id'=>11,'baseroute'=>'admin/man.user'];
        $res=$ControllerM->replaceVal($str);
       // $ControllerM->confToACT('mocontrollerGroup','task1');
      //  $this->assertEquals($res,'ggg/11/admin/man.user/crrr');
        $this->assertTrue(false);
    }

/* public function testreplaceACT()
    {
        //config(['mocontrollerGroup.groupconf'=>$this->testBaseArr]);
    
        //$response = $this->call('GET', 'admin/worker');
        $ControllerM = \App::make('Ottomenku\MoController\MoController');
        $ControllerM->DATA['id']=11;
        $ControllerM->ACT['baseroute']='admin/man.user';
        $ControllerM->ACT['str']['strb']=['gg','ggg/{DATA.id}/{ACT.baseroute}/crrr'];
        $ControllerM->replaceACT();
       // $ControllerM->confToACT('mocontrollerGroup','task1');
        $this->assertEquals($ControllerM->ACT['str']['strb'][1],'ggg/11/admin/man.user/crrr');
    }
    public function testsetUrlParamWithTask()
    {

        Route::group(['prefix' => 'admin'], function () {
            Route::any('te,st1/{task}/{id}/{id1}/{id2}', '\Ottomenku\MoController\MoController@setUrlParamWithTask')
                ->name('dashboard');
        });

        $response = $this->call('GET', 'admin/test1/task/id/id1/id2');
        // $ControllerM  = app(\App\Http\Controllers\ControllerM::class)->viewJson( $data);
        $ControllerM = \App::make('Ottomenku\MoController\MoController');
        $ControllerM->setUrlParamWithTask('task', 'id', 'id1', 'id2');
        $ACT = $ControllerM->ACT;

        $this->assertEquals($ACT, ['prefix' => 'admin', 'routname' => 'dashboard', 'task' => 'task',
            'urlparams' => ['id' => 'id', 'id1' => 'id1', 'id2' => 'id2']]);

    }
*/
}

