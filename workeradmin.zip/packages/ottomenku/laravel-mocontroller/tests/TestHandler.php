<?php

namespace Ottomenku\MoController\Tests;

//use Ottomenku\MoController\MoController;
use Ottomenku\MoController\MoControllerNoauto;

class TestClassToOB1 
{ public $testclasPar1=1;}
    class TestClassToOB2 
{public $testclasPar2=1;}  

class TestHandler extends MoControllerNoauto
{
  /**
     * a controllerből felülírni kívánt paraméterek
     */
    public $PAR= [
'base'=>[
    'basedat'=>[ 'parPlusKey'=>'ok','overkey'=>'par','overkeyTask'=>'parBase',],   //felül kell írja az előző baseadatot
    'parPlusBaseDat'=>'ok','datForDel'=>'ok'
],
'task1'=>[ 
    'basedat'=>[ 'parPlusTaskKey'=>'ok','overkeyTask'=>'parTask1',],   //felül kell írja az előző baseadatot
    'parPlusTask1Dat'=>'ok',
    'functions'=>[['name'=>'testFunc2','par'=>[]]],
    'datForDel'=>'ok'
],
'task2'=>[],

    ];

     public $res;
     public $log;
     public function logMo($Par=[])
     {
        $this->log[]=$Par;
     }
     public function logAlert($Par=[])
     {
        $this->log['alert'][]=$Par;
     }
     public function logError($Par=[])
     {
        $this->log['error'][]=$Par;
     }


     public function propertiesToResAndResponse($PropArr=['PAR','MT','ACT','log'])
     {
        $this->propertiesToRes($PropArr);
         return response()->json($this->res); 
     }



    public function propertiesToRes($PropArr=['PAR','MT','ACT'])
    {
        foreach($PropArr as $propname){
          $this->res[$propname] = $this->$propname;  
        }
        
  
 
    }
    /**nem igazán kellenek  acontrollert a routname helyttsíti. a controller fügvényt a task
   /* 
    public function runFuncAndRes($func, $id = null, $id1 = null, $id2 = null, $id3 = null)
    {
        $this->$func($id, $id1, $id2, $id3);
        $this->propertiesToRes();
        return response()->json($this->res);
    }

    public function runFuncAndResWithTask($func, $task, $id = null, $id1 = null, $id2 = null, $id3 = null)
    {
        $this->$func($task, $id, $id1, $id2, $id3);
        $this->propertiesToRes();
        return response()->json($this->res);
    }

  */
    public function testFunc1($par=['funcname'=>'testFunc1'],$b=1)
    {
        if(is_array($par)){$this->MT['testfunctions'][]=$par['funcname'];}
         else{
            return 'this-'.$par.'-'.$b;  
         }
        
    }
    public function testFunc2($par=['funcname'=>'testFunc2'])
    {
         $this->MT['testfunctions'][]=$par['funcname'];
    }
    public function testFunc3($par=['funcname'=>'testFunc3'])
    {
         $this->MT['testfunctions'][]=$par['funcname'];
    } 
    public function voidFunc($a,$b)
    {
         $this->MT['testfunctions']['voidFunc']=$a.$b;
    }
}
