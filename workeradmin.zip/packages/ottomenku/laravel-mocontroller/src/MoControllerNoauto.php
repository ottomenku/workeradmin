<?php

namespace Ottomenku\MoController;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route as RouteF;

/**
 * a taszteléshez kellet már lényegében pont ebben van automatizmus, a request betöltés
 */
class MoControllerNoauto extends MoController
{
    public function __construct(Request $request)
    {
        $this->OB['Request'] = $request;
    }
    public function testbase( $id = null, $id1 = null, $id2 = null, $id3 = null)
    {

    }
}
