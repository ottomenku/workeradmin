<?php

namespace Ottomenku\MoController\Trt\Crud;

trait Basecrud
{
    public function indexSetData()
    {
        $searchinput = $this->ACT['searchinput'] ?? 'search';
        $keyword = $this->OB['Request']->get('') ?? $searchinput;
        $paginate =$this->ACT['paginate'] ?? 25;
        $searchcolumns =$this->ACT['searchcolumn'] ?? [];

     if (!empty($keyword) && !empty($searchcolumns)) {
            $this->OB['baseOB']->where('title', 'LIKE', "%$keyword%");
            foreach ( $searchcolumns as  $searchcolumn) {
            $this->OB['baseOB']->orWhere($searchcolumn, 'LIKE', "%$keyword%");
            }      
        }
         return $this->OB['baseOB']->latest()->paginate($paginate);   
    }

    public function index()
    {
     // $data= $this->DATA;
    //  $viewpar= $this->ACT['viewpar'];
     // return view($this->ACT['view'], compact('data','viewpar'));
    // $this->funcArrRun($this->ACT['funcs'] ?? []);
   // return $this->moView($this->get('ACT.viewpar.Taskviews').'.'.$this->get('ACT.viewpar.view'));
  return dump($this->ACT);
  }


    public function create()
    {
    //  $data= $this->DATA;
     // $viewpar= $this->ACT['viewpar'];
     // return view($this->ACT['view'], compact('data','viewpar'));
     $this->funcArrRun($this->ACT['funcs'] ?? []);
     return $this->moView($this->get('ACT.viewpar.Taskviews').'.'.$this->get('ACT.viewpar.view'));
    }

  
    public function store(Request $request)
    {
      /*  $this->validate($request, [
			'title' => 'required|max:10'
		]);
        $requestData = $request->all();
        
        Post::create($requestData);

        return rfuncArrRunedirect('admin/posts')->with('flash_message', 'Post added!');*/
        $this->funcArrRun($this->ACT['funcs']);
        return redirect($this->ACT['redirect'])->with('flash_message',$this->ACT['flash_message']);
    }

    public function show($id)
    {
      $this->funcArrRun($this->ACT['funcs']);
      return $this->moView($this->ACT['view']);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($id)
    {
      $this->funcArrRun($this->ACT['funcs']);
      return $this->moView($this->ACT['view']);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $id)
    {
      $this->funcArrRun($this->ACT['funcs']);
      return redirect($this->ACT['redirect'])->with('flash_message',$this->ACT['flash_message']);
       /* $this->validate($request, [
			'title' => 'required|max:10'
		]);
        $requestData = $request->all();
        
        $post = Post::findOrFail($id);
        $post->update($requestData);

        return redirect('admin/posts')->with('flash_message', 'Post updated!');*/
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function destroy($id)
    {
      $this->funcArrRun($this->ACT['funcs']);
      return redirect($this->ACT['redirect'])->with('flash_message',$this->ACT['flash_message']);
      /*  Post::destroy($id);

        return redirect('admin/posts')->with('flash_message', 'Post deleted!');*/
    }

}