<?php

namespace Ottomenku\MoController\Trt\Funcrun;

/**
 * teljes funkcionalitású funcRun, paraméterekkel osztállyal, visszatérési értékkel
 * nem associatív tömbben tárolja a függvényhívás adatait, áttekinthetőbb de kötöttebb
 *  * exaample: 'obkey.funktionName'=>[['string','user.id_DATA'],'data.res_ACT'],
 * obkey: a $this->OB-ban tárolt objektum kulcsa. Nem az osztály vagy az objektum neve!!!!!
 *  data.res_ACT: (string) ez adja meg hova írja a visszatérési értéket
 * az első tag ('_'- jellel elválasztva) az adat elérési útja. A második tag a property neve
 * max 5 par! to lehet void vagy null
 */
trait FuncrunFull
{ 
    public function toProp($val,$dotkey=null)
    {
        // a $to-nak üres string void és null esetén is voidnak kell lennie
       if(empty($dotkey)){ $to = 'void';}else{$to = $dotkey;}
        //res helyének megállapítása ha nem void a függvény       
                if ($to != 'void') {
                    $toArr = explode('.', $to);
                    if (isset($toArr[1])) {
                        $propName = array_shift($toArr);
                        $toDot = implode('.', $toArr);
        // res értékének beírása             
                        array_set($this->$propName, $toDot, $val);
                    } else {
                        $propName = $toArr[0];
                        $this->$propName = $val;
                    }
                }
    }
    /**
     * példák:funcs =>[1=> ['obkey::funktionName',['string','ACT.user.id','DATA.'],'ACT.res'],2=>['funktionName',[],'DATA'],3=>['funktionName',[]]

     *  obkey: a $this->OB-ban tárolt objektum kulcsa. Nem az osztály vagy az objektum neve!!!!!
     * ha az obkey this, elhagyható, alapból azt hívja paraméterekben a property név után mindenképpen kell pont különben stringnek veszi
     *  A funktionName-et lehet * jellel indexelni ha többször is meghívjuk hogy ne legyen egyforma kulcs
     */
    public function funcRun($func = [])
    { 
            $params=[]; $obkeyAndFuncString=$func[0];
            $params = $this->getFuncParamS($func[1] ?? []);
    //key bontása OB-névre és function névre 
         $obkeyAndFuncArr =explode('::', $obkeyAndFuncString); 
            if (isset($obkeyAndFuncArr[1])) {
                $funcname = $obkeyAndFuncArr[1];
                $obKey = $obkeyAndFuncArr[0];}
            else { 
                $funcname = $obkeyAndFuncArr[0];
                $obKey = 'this';} // ha nincs első tag, obname: this ()

            $ob = $this->OB[$obKey] ?? $this;

            if($obKey!='this' && $ob==$this){$this->logErr('nem létező funkcio:'.$obkeyAndFuncString.', Laravel-mocontroller/trt/FuncrunFull');}
            $res = $ob->$funcname($params[0] ?? null, $params[1] ?? null, $params[2] ?? null, $params[3] ?? null, $params[4] ?? null) ;
           $this->toProp($res,$func[2] ?? 'void');
    }
    public function funcArrRun($funcs = [])
    { 
        foreach ($funcs as $func) {
           $this->funcRun($func); 
        }
    }


    /**
     * A param stringet felbontja elérési útra és property névre
     * ez alapján visszatér az aktuális proprty aktuális értével
     * example $paramstring: 'DATA.'a property név után mindig kell '.' különben stringnek veszi,'DATA.user.id' vagy 'sima string'
     */
 /*   public function getFuncParam($paramstring = '')
    {
        $toArr = explode('.', $paramstring);

        if (isset($toArr[1])) {
            $propName = array_shift($toArr); //az első tagot veszi ki a tömbből
            if (empty($propName[0])) { //a teljes propertyvel tér vissza
                $res = $this->$propName;} else {
                $toDot = implode('.', $toArr);
                $res = array_get($this->$propName, $toDot);
            }
        } else { $res = $paramstring;} //string

        return $res;
    }*/
    /**
     * example $params: ['user.id_DATA', 'list_ACT' , 'sima string']
     * Max 5 param
     */
    public function getFuncParamS($params = [])
    {
        $res = [];
        foreach ($params as $param) {
           $res[]=$this->replaceVal($param);
        }

        return $res;
    }
}
