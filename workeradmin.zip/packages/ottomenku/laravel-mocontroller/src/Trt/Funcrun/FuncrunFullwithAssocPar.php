<?php

namespace Ottomenku\MoController\Trt\Funcrun;

/** 
 * nincs kész------------------------------------
 * exaample: [['func'=>'funcname',par'=>['get.id,ACT','user.name,DATA','user,DATA',
 * 'sima string'],'to'=>'user.name,DATA','ob'=>'obkulcs', ]]
 * max 4 par! to lehet void
*/
trait FuncrunFullwithAssocPar
{
use \Ottomenku\MoController\Trt\Funcrun\FuncrunHandler;
    public function funcRun($funcs = [])
    {
      foreach ($funcs as $funcassoc) {
        $funcname= $funcassoc['func'] ;
        $params  = $this->getFuncParamS($funcassoc['par']);
        $count=count($params);

        $funcob=$funcassoc['ob'] ?? 'this';  
        $ob=$this->OB[$funcob]  ??  $this;
          //  $ob->$funcname();
            switch ($count) {
                case 1:
               $res= $ob->$funcname($params[0])  ?? '';
                    break;
                case 2:
                $res= $ob->$funcname($params[0],$params[1]) ?? '';
                    break;
                case 3:
                $res= $ob->$funcname($params[0],$params[1],$params[2]) ?? '';
                    break;
                case 4:
                $res= $ob->$funcname($params[0],$params[1],$params[2],$params[3]) ?? '';
                    break;
                case 5:
                $res= $ob->$funcname($params[0],$params[1],$params[2],$params[3],$params[4]) ?? '';
                        break;       
                default:
                $res= $ob->$funcname()  ?? '';   
            }
            $to=$funcassoc['to'] ?? 'void';
            if($to!='void')
            {
                $toArr=explode('_',$to);
               $propName =$toArr[1] ?? 'DATA';
                array_set($this->$propName, $toArr[0], $res);

            }
        }
    }
    /**
     * A param stringet felbontja elérési útra és property névre 
     * ez alapján visszatér az aktuális proprty aktuális értével
     * example $paramstring: 'DATA.'a property név után mindig kell '.' különben stringnek veszi,'DATA.user.id' vagy 'sima string'
     */
    public function getFuncParam($paramstring = '')
    {
        $toArr = explode('.', $paramstring);
    
        if (isset($toArr[1])) {
            $propName = array_shift($toArr);
            if(empty($propName[0])){ //a teljes propertyvel tér vissza
                $res=$this->$propName;}
            else{
                $toDot=implode('.',$toArr);
                $res = array_get($this->$propName,  $toDot);
            }
        } else { $res = $paramstring;} //string

        return $res;
    }
    /**
     * example $params: ['user.id_DATA', 'list_ACT' , 'sima string'] 
     * Max 5 param
     */
    public function getFuncParamS($params = [])
    {
        $res = [];
        foreach ($params as $paramstring) {
            $res[] = $this->getFuncParam($paramstring);
        }

        return $res;
    }
}