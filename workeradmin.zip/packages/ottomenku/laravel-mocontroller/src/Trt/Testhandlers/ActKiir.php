<?php

namespace Ottomenku\MoController\Trt\SetAct;

/**
 * Az alap config fájlnak a gyökérben kell lennie mocontroller.php néven
 * A többi config file a mocontrollerDir-ben
 * A route groupok ha vannak öröklik és felülírhatjákaz alap configot a rout alap konfigok a route.php-ban vannak
 * Minde route groupoknak külön könytárat kell csinálni néven
 * (elvileg a könyvtáratki lehet váltani groupname+Dir.php fájlal is ekkor a kulcsai lesznek a routname.php-k  )
 * minden routname-nek külön fájl kell havna rot dir. 
 * Ha a routnak nincs neve vagy másik konfig fájlt akarunk hozzá rendelni rout változóként is lehet konfig file nevet küldeni.
 * A name konfig fájlok oroklik és felül írhatják a group és (ezen keresztül az alap) konfigok értékeit
 * A task vagy rout változóként érkezik vagy a crud task. A hozzá tartozó értékek a konfig fajlok fő kulcsai. 
 * ezen kívül még a konfig fájlkoknak lehet base kulcsa amit szintéb örökölnek és felül írhatnak a taskok.
 * és 
 */
trait ActKiir
{
    public function basekiir( $id = null, $id1 = null, $id2 = null, $id3 = null)
    {
       
        $this->setUrlParam($id, $id1, $id2, $id3);
        $this->funcRun();
        var_dump($this->ACT);
    } 
}

   
?>
