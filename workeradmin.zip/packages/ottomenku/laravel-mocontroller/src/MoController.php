<?php

namespace Ottomenku\MoController;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Routing\Route;
//use Illuminate\Support\Facades\Log;
//use Illuminate\Support\Facades\Route as RouteF;
//use PhpParser\Node\Stmt\Foreach_;

/**
 * a __construct nem hvja meg automatikusan a beállító függvényeket
 */
class MoController extends Controller
{
    /**
     * a controllerből felülírni kívánt paraméterek használatához meg kell hívni a parToAct() függvényt
     */
    public $PAR = [];
    // public $viewPar = [];
    public $configpath = 'mocontroller'; //lényegében a config fájlok könyvtára,persze lehet fájl is a nagyon egyszerú a weblap
    public $baseconfig = 'groupconf'; // A mocontroller default értékei, lehet a Groupoknak is.
    //beépülnek a config szerkezetbe Lépcsőzetes felépítésúek(szülő-gyermek) 

    /**
     * Konfig fájlok egymásra másolására és átmenetei tárolónak
     */
    public $MT = [];
    /**
     * objektumok tárolásásra. ha az ACT-ba tennénk nem lehetne az ACT-ot kiíratni memória túlcsordulás miatt
     */
    public $OB = [];
    /**
     * az aktuális, használandó paraméterek a viewpar kulcs adatai lesznek átadava a viewnek
     */
    public $ACT = [];
    /**
     * a generált adatok ide kerülnek 
     */
    public $DATA = [];

    public function validateToDATA()
    {
        $roles=$this->ACT['validations'] ?? [];
        $this->OB['Request']->validate($roles);
        return $this->OB['Request']->all();
    }

    public function replaceArr($arr)
    {
        $changed=[];
        foreach ($arr as $key => $value) {
            if(is_array($value)){$changed[$key]=$this->replaceArr($value);}
            else{
                // if (strpos($value, '{') !== false) {
                $changed[$key]=$this->replaceVal($value);
               //  }
            }
        }
  return $changed;
    }
    /**
     * Az ACT értékeiben a { } jelek között lévő dotkey kulcsokat kicsréli a kulcsok értékeire
     *  $this->ACT['replaceACT'] -ban lehet tiltani
     * pl ACT['Id']='ggg/{DATA.id}/' ből lesz:'ggg/11/' ha a DATA['id']=11;
     */
    public function replaceACT()
    {     
      //  $replaceACT=$this->ACT['replaceACT'] ?? true;
     //   if($forced){$replaceACT= true;}
     //   if($replaceACT){          
        $changed=[];
            foreach ($this->ACT as $key => $value) {
                if($key=='funcs'){// afuncs paramétereket ne bántsa mert egymásra épülnek
                    $changed[$key]=$value;
                }
                else{
                    if(is_array($value)){$changed[$key]=$this->replaceArr($value);}
                    else{
                // if (strpos($value, '{') !== false) {
                    $changed[$key]=$this->replaceVal($value);     //  }
                    } 
                }    
            }
         $this->ACT=$changed;
    //    }
        
    }
    
/**
 * A $str változóban {} jelek között lévő dotkey kulcsokat kicsréli a kulcsok értékeire
 * pl $str='ggg/{DATA.id}/' ből lesz:'ggg/11/' ha a DATA['id']=11; lehet több gg{ACT}dfsf{ACT.id}
 * Ha csak dotkey kulcs van pl {ACT} vagy {ACT.id} akkor annak az értékével tér vissza lehet tömb vagy objektum is
 */
    public function replaceVal($str)
    {   $res=$str;
        if(is_string($str)){
        $outarr=[];
        $count= preg_match_all('/\{(.*?)\}/', $str, $outArr);
        switch ($count) {
            case 1:
                //Ha string csak egy dotkey kulcsot tartalmaz mást nem pl.: {ACT}
               //lehet tömb vagy objektüm is a visszatérési érték
               if(substr($str, 0,1)=='{' && substr($str, -1)=='}'){
               $res=$this->get($outArr[1][0]);
                }else{
                    // ha csak egy dotkey kulcs vaan de stringben
                    //behelyettesíti és stringel tér vissza
                    $arrVal=$this->get($outArr[1][0]);
                    $res= str_replace('{'.$outArr[1][0].'}', $arrVal, $str);
                }
                break;
            case 0:
                // ha string csak vissza adja
                $res=$str;
            break;
            default:// több dotkey kulcs esetén mindegyiket behelyettesíti az értékével stringel tér vissza
                foreach ($outArr[1] as  $value) {
                    $arrVal=$this->get($value);
                    $res= str_replace('{'.$value.'}', $arrVal, $res);
                }   
                break;
        }  
        }
    
        return $res;
    }

    /**
     * a viewnwk átadandó adatok ha a DATA tömbben is kell, akkor oda másoljuk az értéket itt a data kuilcsal hivatkozunk rá
     */
    public function dataTo($value,$to='DATA')
    {  
         $dotkeys=explode('.',$to);
        $prop=array_shift($dotkeys);
        array_set($this->$prop, implode('.',$dotkeys), $value);
    }

/**
 * lefuttatja a taskhoz tartozó funkciókat. Traittel felülírható ha pl DI-t akartunk használni vagy paraméterezett fájlokat
 */
/*public function funcRun($funcs = [])
{
    if (empty($funcs)) {$funcs = [];}
    if (!is_array($funcs)) {$funcs = explode(',', $funcs);}
    foreach ($funcs as $funcname) {
        $this->$funcname();
    }
}*/
/**
 * returnal kell meghívni
 */
public function moView($view=null, $dataname = 'data', $paramname = 'viewpar', $ACTkey = 'viewpar')
{
    $viewfull=$view ?? $this->get('ACT.viewpar.Taskviews').'.'.$this->get('ACT.viewpar.view');
    $$dataname = $this->DATA;
    $$paramname = $this->ACT[$ACTkey];
    return view($viewfull, compact($dataname,$paramname));

}
/**
 * Erre kell irányítíni a routot ha nem resourcest használunk A resources taskjai is ezt híják meg
 * A config fájlok a a rout paraméterek alapján töltődnek be. (groupname routname)
 *  Task a routname utolsó tagja. resources routok automatikusan oda teszik az aktuális crud taskot. 
 */ 
public function base( $id = null, $id1 = null, $id2 = null, $id3 = null)
{
    $this->setConfigFromRoutname();
    $this->setParam($id, $id1, $id2, $id3);
    $this->funcRun($this->ACT['funcRun'] ?? []);
    $redirect=$this->ACT['redirect'] ?? '';
  
    if($redirect!=''){return $redirect;}
    else{return $this->ACT['return'] ; }

}





 // setterek*********************************************************************** 
    
 public function setrequest(Request $request)
    {
        $this->OB['Request'] = $request;
    }
 
    public function setRoutPars($id = null, $id1 = null, $id2 = null, $id3 = null)
    {
        $args = get_defined_vars();
        foreach ($args as $key => $value) {
            if ($value != null) {
             $this->ACT['routpars'][$key]=$this->ACT['viewpar']['routpars'][$key] = $value; // id1,id2,id3...
            }
        }
    }

    /**
     *  nevet ad az url paramétereknek, ha nincs ACT['routpars']['Alias'] akkor a név ugyanaz lesz mint ACT['routpars']['byParName']
     */
    public function setParamAlias()
    {
        foreach ($this->ACT['routpars']['byParName'] as $key => $value) {
            if ($value != null) {
                $name = $this->ACT['routpars']['Alias'][$key] ?? $key;
                $this->ACT['routpars']['byAlias'][$name] = $value;
            }

        }
    }

/**
 * feltölti az ACT['ob'] tömböt. a használni kívánt osztályokkal
 */
    public function setOB()
    {
        $obClass=$this->ACT['obClass'] ?? [];
        foreach ($obClass as $obName => $className) {
            $this->OB[$obName] = new $className();
        }
    }
    public function setConfig($routePartS)
 { 
    $task=$this->ACT['task'];
     $configpath='';
     foreach ($routePartS as $part) { 
         if($configpath==''){$configpath=$part; }
         else{$configpath.='.'.$part; }             
         $this->confToACT($configpath,$task);  
        // $this->ACT['path'] .= '-----'.$configpath ;  
         }        
 }
    public function setConfigFromRoutname()
 { 
     $routePartS=$this->setRoutname();
     $routePartS=$this->setTask($routePartS);
    $this->setConfig($routePartS);
         
 }
 //(setconfig handlerek) -----------------------------------------------------
 
 /**
     * alap routnál a name-ben kell megadni pl.:->name('adminGroup.user.taskname'); 
     * resources rout neve  az [as=>'adminGroup.user'] paraméter plusz az aktuális taskot automatikusan hozzáteszi
     */
    public function setRoutname()
    { 
        
        $routname= $this->OB['Request']->route()->getName() ?? '';
        $this->ACT['routname']= str_replace('..', '.',$routname ); 
        $fullpath=$this->configpath.'.'.$routname;

        return  explode('.',$fullpath);
      
    }
    public function setTask($routePartS)
    { 
        $this->ACT['task']=array_pop($routePartS); 
        return $routePartS; 
    }
  
/**
 * Ha az akt Group-ra végződik a benne lévő groupconf-ból tölti fel az actot 
 * Ha nem akkor a pathnak megfelelő configból
 */
public function confToACT($path,$task)
    {
        $gropconfOrDot='.';
        if(substr($path,-5,5) =='Group'){ $gropconfOrDot='.groupconf.';  }
            
        $this->removeFromProp('ACT',config($path.$gropconfOrDot.'base.delParrent'));
        $this->mergeParWithProp('ACT', config($path.$gropconfOrDot.'base'));

        $this->removeFromProp('ACT',config($path.$gropconfOrDot.$task.'delParrent'));
        $this->mergeParWithProp('ACT', config($path.$gropconfOrDot.$task));  
    }
  /**
     * eltávolíthatjuk vele a nem kívánt elemeket kulcsokat a szülő konfigurációs fájlokból ($propname)
     * A $dotkeys lehet tömb, vagy string. Nem létező elemnél sem jelez hibát, nme cinál semmit
     */
    public function removeFromProp($propname, $dotkeys='')
    {
       if (!is_array($dotkeys)) {$dotkeys = explode(',', $dotkeys);}
        foreach ($dotkeys as $dotkey) {
           array_forget($this->$propname, $dotkey);
        }
    }
    /**
     * hogy meg lehessen hívni a funcs-bam és a dotkeyt stringként lehessen átadni 
     * alapból a funcrun() a dot keyt kicseréli az értékére Itt Aláhúzás jellel is meg lehet adni
     */
    public function remove($propname, $underkeys='')
    { 
        $propname= str_replace('_','',$propname);
        $dotkey= str_replace('_','.',$underkeys);
           array_forget($this->$propname, $dotkey);
    }

      /**
     * $mergeArr.delFromParrent alapján törli az MT nem kívánt kulcsait
     * lefuttatja $mergeArr.setupFuncs beállító metódusait, maj egyesíti a $baseArr-t és a $mergeArr-t
     */

    public function mergeParWithProp($propname, $mergeArr = [])
    {
        if (!is_array($mergeArr)) {$mergeArr = [];}
        $delFromParrent = $mergeArr['delFromParrent'] ?? [];
        $this->removeFromProp($propname, $delFromParrent);
        $this->$propname = array_replace_recursive($this->$propname, $mergeArr);
      //  $setupfunc = $mergeArr['setupfunc'] ?? [];
       // $this->funcRun($setupfunc);
    }
    /**
     * visszatér az adott property dotkey értékével 
     * Pl get('ACT')= $this->ACT,   get(ACT.id)=$this->ACT['id']
     */
    public function get($dotkey)
    {
     $dotkeys=explode('.',$dotkey);
     $prop=array_shift($dotkeys);
     if(empty($dotkeys)){return $this->$prop;}
     else{return \Arr::get($this->$prop,implode('.',$dotkeys));}
    
    }
    public function ACTkiir()
    {
      dump($this->ACT);
    }
    public function DATAkiir()
    {
      dump($this->DATA);
    }
// logolás-------------------------------------------------------
    public function loggg()
    {
       // Log::alert('whrfokpihfroiwerfwoierf', ['id' => '12']);
        // Log::error('whrfokpihfroiwerfwoierf');
    }
    public function logAlert($alertMessage,$Par = [])
    {
       // activity()->log($alertMessage);
    }
    public function logErr($errorMessage,$Par = []) //path='namespace/class/fnctiona',param= [param]
    {
        //activity()->log($errorMessage);
    }
}
