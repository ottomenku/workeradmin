<?php

//namespace Ottomenku\MoController;
/**
 * törli az adott tömbből az adott dot kulcsot 
 * lényegében array_forget($arr, $dotkey); csak lehet neki tömbben
 * vagy veszzővel elvállasztva stringben több értéket megadni
 */
if (! function_exists('delFromParrent')) {
   
    function delFromParrent($arr, $dotkeys='')
    {
       if (!is_array($dotkeys)) {$dotkeys = explode(',', $dotkeys);}
        foreach ($dotkeys as $dotkey) {
           array_forget($arr, $dotkey);
        }
        return $arr;
    }
}

if (! function_exists('replaceStr')) {
/**
 * A $str változóban {} jelek között lévő dotkey kulcsokat kicsréli a kulcsok config értékeire
 * pl $str=/{par.id}' ből lesz:'ggg/11/2' ha a config(DATA.id)=11 és a config(par.id)=2;
 * Ha $removeProp=true akoor a properti neveket eltávolítja 'ggg/{DATA.id} ből lesz ggg/{id}
 */   
    function replaceStr($str,$removeProp=true) //$remove lehet pl act
    {
        if($removeProp){$str = str_replace(['ACT.','DATA.'], "", $str );}
        preg_match_all('/\{(.*?)\}/', $str, $outArr);
        foreach ($outArr[1] as  $dotkey) {
            $arrVal=$str=config($dotkey);;
            $str= str_replace('{'.$dotkey.'}', $arrVal, $str);
        }
        return $str;
    }
}

if (! function_exists('setConf')) {
   /**
 * az alap konfig kulcs($confkey) alatt egyesíti az alap konfig, $base_par, $viewpar tömböket
 * hogy a paramétereket config()-al leheseen lekérni. kÖnnyú alap értéket adni, és nem kell  vizsgálni hogy létezik-e a kulcs
 */
    function setConf($base_par,$viewpar, $confkey='par')
    {
        $conf_par=config($confkey, []);
        $base_conf_par=array_replace_recursive($conf_par, $base_par);
        $delFromParrent = $viewpar['delFromParrent'] ?? [];  
        $base_conf_par=delFromParrent($base_conf_par,$delFromParrent); 
        config([$confkey=>array_replace_recursive($base_conf_par, $viewpar)]);
    }
}