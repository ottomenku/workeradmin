<?
namespace Ottomenku\MoController;

use Illuminate\Support\ServiceProvider;

class MocontrollerServiceProvider extends ServiceProvider
{ 
     public function boot()
    {
        $this->publishes([
            // Config
            __DIR__.'/../config/' => config_path('mocontroller'),
            
            // Views
           // __DIR__.'/../resources/views/view-1.blade.php' => resource_path('views/vendor/package/view-1.blade.php'),
           // __DIR__.'/../resources/views/view-2.blade.php' => resource_path('views/vendor/package/view-2.blade.php'),
            
            // Translations
            //   __DIR__.'/../resources/lang' => resource_path('lang/vendor/package-name'),
            
            // Assets
            //__DIR__.'/../resources/js' => public_path('vendor/package-name/js'),
            //      __DIR__.'/../resources/css' => public_path('vendor/package-name/css'),
        ], 'laravel-mocontroller');
    }

    public function register()
    {
      /*  $this->app->bind('ottomenku-mocontroller', function() {
            return new MoController;
        });*/
     
     //       require_once glob(__DIR__.'/../helper.php');
     
        
   // require_once base_path() . '/vendor/Helpers/Custom/Helper.php';
//require_once 'packages/ottomenku/laravel-mocontroller/src/helper.php';
    
        $this->app->make(‘Ottomenku\MoController\MoController’);
    }
}

