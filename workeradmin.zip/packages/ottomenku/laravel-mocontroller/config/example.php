<?php

return [
        //alapadatok ami minden taskra érvényesek-----------------------------
        'base'=>[
                //'task'=> 'index',     
                'basedat'=>[ 'key3'=>'ok','key2'=>'ok2',],   
                'key'=>'ok2',
                 //ezeket példányosítja a this->OB -ba az itteni kulcs lesz az ottani kulcs
                'obClass'=>['Mohandler'=>'Ottomenku\MoController\mohandlerOb' ],
                'validate'=>[
			'end' => 'time',
			'hour' => 'required|integer|max:24',
			'managernote' => 'string|max:200',
                        'pub' => 'integer',
                        'image' => 'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                        'tb' => 'string|max:50|nullable',
                        'start' => 'required|date',
                        'end' => 'date_format:H:i',
		],
        ],
        //taskok adatai az aktuális taskkal felülírja a base értékeket-----------------------------
        'index'=> [ 
                //az előző configok által már beírt zavaró külcsok és értékeik törlése először ez hajtódik végre
                'delFromParrent'=>'base.datForDel,task1.basedat.datForDel,task1.functions,bb.cc', 
                'basedat'=>[ ],  
                'key2'=>'ok',
                // a task által lefuttatandó függvények
                'functions'=>[
                        1=>['testFuncWithRes',[],'index.view,ACT'],
                        2=>['testFuncWithPar',['base.dt,MT','string']],
                        3=>['testFunc',[]]
                ],  
                //nem használt, be lehet írni a functionsba.Eredetileg ha szükséges volt vbeállító függvény lefuttatása 
                'setupfunc'=>['testFunc1','testFunc2'],
          
        ],
        'task2'=>[
                ['arr'],['arr2']
        ],
           
];
