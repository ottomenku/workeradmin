MoController to Laravel

install:
composer require ottomenku/laravel-mocontroller