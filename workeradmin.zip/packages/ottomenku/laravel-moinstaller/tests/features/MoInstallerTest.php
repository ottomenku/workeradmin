<?php

namespace Tests\Features;
use PHPUnit\Framework\TestCase as BaseTestCase;
//use Illuminate\Support\Facades\Artisan;
//use Artisan;
class MoInstllerTest extends BaseTestCase
{
  //use CreatesApplication;


    public function memoryDB()
    {
        config(['database.default' => 'sqlite_testing']);
        \Artisan::call('migrate'); 
           \Artisan::call('db:seed'); 
    }

    public function testModelGen()
    {
       // Storage::put('app/mytextdocument.php','John Doe');
      /* $gg=new \Ottomenku\MoInstaller\ModelGenerator('jjj'); 
       $res=$gg->buildClass('post');
        $fp = fopen('app/post.php', 'w');
        fwrite($fp, $res);
        fclose($fp); */
        //parent::setUp(); 
       // \App::make('artisan')->call("php artisan crud:model Post --fillable=['title', 'body']");
      // \Artisan::call("php artisan crud:model Post");
        $this->assertEquals('john','john');
    }
 




}
