<?php

namespace Ottomenku\MoInstaller;

use Illuminate\Http\Request;

class MoInstaller 
{

    public function __construct(Request $request)
    {
        $this->OB['Request'] = $request;
         //a baseconfig benásolása  az MT-be
        $this->baseConfToMT();
        // groupconfig ha nem kell csak ki kell slashelni
        $this->groupConfToMT();
        //routname config
        $this->routnameConfToMT();
        //Par config
        $this->PARToMT();
    }

}
