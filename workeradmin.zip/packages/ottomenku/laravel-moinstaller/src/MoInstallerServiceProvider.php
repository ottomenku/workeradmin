<?
namespace Ottomenku\MoInstaller;

use Illuminate\Support\ServiceProvider;

class MoInstallerServiceProvider extends ServiceProvider
{ 
     public function boot()
    {
        $this->publishes([
            // Config
            __DIR__.'/../config/moinstaller.php' => config_path('moinstaller.php'),
            
            // Views
           // __DIR__.'/../resources/views/view-1.blade.php' => resource_path('views/vendor/package/view-1.blade.php'),
           // __DIR__.'/../resources/views/view-2.blade.php' => resource_path('views/vendor/package/view-2.blade.php'),
            
            // Translations
            //   __DIR__.'/../resources/lang' => resource_path('lang/vendor/package-name'),
            
            // Assets
            //__DIR__.'/../resources/js' => public_path('vendor/package-name/js'),
            //      __DIR__.'/../resources/css' => public_path('vendor/package-name/css'),
        ], 'laravel-MoInstaller ');
    }

    public function register()
    {
      /*  $this->app->bind('ottomenku-mocontroller', function() {
            return new MoInstaller ;
        });*/
      
    }
}

